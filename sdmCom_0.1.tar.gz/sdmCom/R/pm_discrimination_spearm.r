#' @title Discrimination measure for species richness and community composition
#'
#' @param species_richness Species richness (from modify_predictions)
#' @param community_composition Community composition (from modify_predictions)
#' @return Spearman rank correlation among sites/regions, based on predictive mean
#'
#' @details Measures 2B and 3B from Norberg et al. (2019)

pm_discrimination_spearm <- function(species_richness = NULL,
                                     community_composition = NULL,
                                     as_array) 

{
    sp_rich_spear <- NULL
    comm_comp_spear <- NULL
    
    if (!is.null(species_richness)) {

        if (as_array) {
            sp_rich_spear <- NA
        } else {
            sp_rich_spear <- vector("list", length(species_richness$predicted))
            names(sp_rich_spear) <- names(species_richness$predicted)
        }
    
        for ( m in 1:length(species_richness$predicted) ) {

            tmp <- vector("list", length(species_richness$predicted[[m]]))
            names(tmp) <- names(species_richness$predicted[[m]])

            for ( f in 1:length(species_richness$predicted[[m]]) ) {
                tmp1 <- NULL            
                tmp1 <- apply(species_richness$predicted[[m]][[f]], 
                              2, 
                              cor, 
                              y = species_richness$validation, 
                              method = "spearman", 
                              use = "complete.obs")
                tmp[[f]] <- mean(tmp1, na.rm = TRUE )
                if (sum(is.na(tmp1)) > 0) {
                    print(paste(sum(is.na(tmp1)),
                                "NAs in correlations between species richnesses"))
                }
                                      
            }

            if (as_array) {
                sp_rich_spear <- rbind(sp_rich_spear,
                                      cbind(names(species_richness$predicted)[m], 
                                      names(tmp), 
                                      unlist(tmp))) 
            } else {
                sp_rich_spear[[m]] <- tmp
            }
    
        }
        if (as_array) {
            sp_rich_spear <- matrix(sp_rich_spear[-1,], ncol = 3)
        }
    }

    if (!is.null(community_composition)) {

        if (as_array) {        
            beta_sim_spear <- NA
            beta_sne_spear <- NA
            beta_sor_spear <- NA
        } else {
            beta_sim_spear <- vector("list", length(community_composition$beta_sim))
            names(beta_sim_spear) <- names(community_composition$beta_sim)
        
            beta_sne_spear <- vector("list", length(community_composition$beta_sne))
            names(beta_sne_spear) <- names(community_composition$beta_sne)
        
            beta_sor_spear <- vector("list", length(community_composition$beta_sor))
            names(beta_sor_spear) <- names(community_composition$beta_sor)
        }

        for ( m in 1:length(community_composition$beta_sim) ) {

            tmp_sim <- vector("list", length(community_composition$beta_sim[[m]]))
            names(tmp_sim) <- names(community_composition$beta_sim[[m]])

            tmp_sne <- vector("list", length(community_composition$beta_sne[[m]]))
            names(tmp_sne) <- names(community_composition$beta_sne[[m]])

            tmp_sor <- vector("list", length(community_composition$beta_sor[[m]]))
            names(tmp_sor) <- names(community_composition$beta_sor[[m]])

            for ( f in 1:length(community_composition$beta_sim[[m]]) ) {

                tmp_sim1 <- NULL
                tmp_sim1 <- apply(community_composition$beta_sim[[m]][[f]], 
                                  2, 
                                  cor, 
                                  y = community_composition$beta_valid[,1], 
                                  method = "spearman", 
                                  use = "complete.obs")
                tmp_sim[[f]] <- mean(tmp_sim1, na.rm = TRUE)
                if (sum(is.na(tmp_sim1)) > 0) {
                    print(paste(sum(is.na(tmp_sim1)),
                                "NAs in correlations between Simpson indices"))
                }

                tmp_sne1 <- NULL
                tmp_sne1 <- apply(community_composition$beta_sne[[m]][[f]], 
                                  2, 
                                  cor, 
                                  y = community_composition$beta_valid[,2], 
                                  method = "spearman", 
                                  use = "complete.obs")
                tmp_sne[[f]] <- mean(tmp_sne1, na.rm = TRUE)
                if (sum(is.na(tmp_sne1)) > 0) {
                    print(paste(sum(is.na(tmp_sne1)),
                                "NAs in correlations between nestedness indices"))
                }

                tmp_sor1 <- NULL
                tmp_sor1 <- apply(community_composition$beta_sor[[m]][[f]], 
                              2, 
                              cor, 
                              y = community_composition$beta_valid[,3], 
                              method = "spearman", 
                              use = "complete.obs")
                tmp_sor[[f]] <- mean(tmp_sor1, na.rm = TRUE)
                if (sum(is.na(tmp_sor1)) > 0) {
                    print(paste(sum(is.na(tmp_sor1)),
                                "NAs in correlations between Sorensen indices"))
                }
            }

            if (as_array) {
                beta_sim_spear <- rbind(beta_sim_spear,
                                       cbind(names(community_composition$beta_sim)[m], 
                                       names(tmp_sim), 
                                       unlist(tmp_sim))) 
                beta_sne_spear <- rbind(beta_sne_spear,
                                       cbind(names(community_composition$beta_sne)[m], 
                                       names(tmp_sne), 
                                       unlist(tmp_sne))) 
                beta_sor_spear <- rbind(beta_sor_spear,
                                       cbind(names(community_composition$beta_sor)[m], 
                                       names(tmp_sor), 
                                       unlist(tmp_sor))) 
            } else {
                beta_sim_spear[[m]] <- tmp_sim
                beta_sne_spear[[m]] <- tmp_sne
                beta_sor_spear[[m]] <- tmp_sor
            }
          
        }
        if (as_array) {
            comm_comp_spear <- cbind(beta_sim_spear[-1,3],
                                       beta_sne_spear[-1,3],
                                       beta_sor_spear[-1,3])            
        } else {
            comm_comp_spear <- list(beta_sim_spear = beta_sim_spear,
                                    beta_sne_spear = beta_sne_spear,
                                    beta_sor_spear = beta_sor_spear)
        }
    }

    if (as_array) {            
        res_arr <- cbind(sp_rich_spear, comm_comp_spear)
        colnames(res_arr) <- c("modelling framework",
                               "model variant",
                               "sp_rich_spear", 
                               "beta_sim_spear",
                               "beta_sne_spear",
                               "beta_sor_spear")
        return( res_arr )                
    } else {
        return(list(sp_richness_spearm = sp_rich_spear,
                    community_composition_spearm = comm_comp_spear))
    }

}
