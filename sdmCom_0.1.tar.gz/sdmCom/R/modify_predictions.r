#' @title Modify predicted occurrences to values of occurrence probability, species richness and community composition
#'
#' @param predictions Predicted occurrences
#' @param yvalid Validation occurrence data
#' @param n_of_site_pairs Number of site pairs to be used for community composition calculation
#' @return A list of occurrence probabilities, species richness and community composition
#'
#' @export

modify_predictions  <- function(predictions, 
                                yvalid,
                                values = c("probabilities",
                                           "richness",
                                           "community"),
                                n_of_site_pairs = 300,
                                avoid_singular = FALSE, 
                                seed = NULL)


{
    occ_probs <- list()
    sp_rich <- list()
    comm_comp <- list()
    
    if ("probabilities" %in% values) {
        occ_probs   <-  sdmCom:::calc_occurrence_probs(predictions = predictions,
                                                      avoid_singular = avoid_singular) 
    }
    if ("richness" %in% values) {
        sp_rich   <-  sdmCom:::calc_sp_richness(predictions = predictions,
                                               yvalid = yvalid) 
    }
    if ("community" %in% values) {
        comm_comp   <-  sdmCom:::calc_betapart(predictions = predictions,
                                              yvalid = yvalid,
                                              n_of_site_pairs = n_of_site_pairs,
                                              seed = seed) 
    }

    return(list(occurrence_probabilities = occ_probs,
                species_richness = sp_rich,
                community_composition = comm_comp,
                y_validation = yvalid))

}
