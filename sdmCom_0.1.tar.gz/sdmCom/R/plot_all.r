#' @title Plot all performance measures
#'
#' @param results Results from calculate_pms()
#' @return All results in one plot
#'
#' @export

plot_all <- function(results) {

    res <- results[,which(colnames(results)=="accuracy_expected_me"):ncol(results)]

    pdf(NULL)
    par(family = "serif", mar = c(10, 2, 2, 1))
    dev.control(displaylist = "enable")
    
    plot(x = 1:ncol(res), 
         y = apply(res, 2, max), 
         type = 'n',
         xaxt = 'n',
         xlab = '',
         ylab = 'Measure value',
         main = 'All performance measures')
         
    axis(side = 1,
         at = 1:ncol(res),
         labels = colnames(res),
         las = 2)
        
    for (i in 1:ncol(res)) {
        lines(x = rep(i, times = 2), 
              y = c(min(res[,i]), max(res[,i])), 
              lwd = 2, 
              col = "red2")
    }
    
    points(x = 1:ncol(res), 
           y = colMeans(res), 
           pch = 16)
    
    plt <- recordPlot()
    
    invisible(dev.off())

    return(plt)
}



