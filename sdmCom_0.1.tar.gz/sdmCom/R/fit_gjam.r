#' @title Fit a Generalized Joint Attribute Model
#'
#' @param dat A list of data matrices (or data frames)
#' @param interactions_x Boolean
#' @param spatial Boolean
#' @param mcmcControl MCMC sampling settings 
#' @return The model fit object and computation time(s)

fit_gjam  <-  function(dat, 
                       poly_degree, 
                       mcmcControl,
                       save_model,
                       save_model_true)
    {

    gjam1 <- list()

    if (poly_degree==1) {
        datx <- dat$x            
    }
    if (poly_degree==2) {
        datx <- dat$x_2           
    }
	colnames(datx) <- letters[1:ncol(datx)]

	form <- as.formula(paste0(".~", paste(letters[1:ncol(datx)], 
	                                      collapse="+")))

    datymat <- as.matrix(dat$y)
	no0sp <- colSums(datymat) !=0 & colSums(datymat) != nrow(datymat)
	datymat_no0sp <- datymat[,no0sp]
    if ( sum(no0sp) >= nrow(datymat) ) {
        dif <- -(nrow(datymat) - sum(no0sp) - 1)
        drp <- order(colSums(datymat_no0sp))[1:dif]
        datymat_no0sp <- datymat_no0sp[,-drp]
    }	
	no0spNames <- colnames(datymat_no0sp)
	
    gjamControl  <- list(ng = mcmcControl$niterTot, 
                         burnin = mcmcControl$nburn, 
                         typeNames = 'PA', 
                         holdoutN = 0)

    gjamControl_rl1  <- list(ng = mcmcControl$niterTot, 
                             burnin = mcmcControl$nburn, 
                             typeNames = 'PA', 
                             holdoutN = 0,
                             reductList = list(r = 2, 
                                               N = 3))

    gjamControl_rl2  <- list(ng = mcmcControl$niterTot, 
                             burnin = mcmcControl$nburn, 
                             typeNames = 'PA', 
                             holdoutN = 0,
                             reductList = list(r = 2,
                                               N = 2))
            
    gjamControl_rl_no_red  <- list(ng = mcmcControl$niterTot, 
                                   burnin = mcmcControl$nburn, 
                                   typeNames = 'PA', 
                                   holdoutN = 0,
                                   REDUCT = F)
    sT <- proc.time()    
    gjam1fit <- NULL
    tryCatch({ gjam1fit <- gjam::gjam(formula = form, 
                                      xdata = as.data.frame(datx), 
                                      ydata = as.data.frame(datymat_no0sp), 
                                      modelList = gjamControl) }, 
                    error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
                    
    if (is.null(gjam1fit)) {
        tryCatch({ gjam1fit	<-	gjam::gjam(formula = form, 
                                           xdata = as.data.frame(datx), 
                                           ydata = as.data.frame(datymat_no0sp), 
                                           modelList = gjamControl_rl1) }, 
                    error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    if (is.null(gjam1fit)) {
        tryCatch({ gjam1fit	<-	gjam::gjam(formula = form, 
                                           xdata = as.data.frame(datx), 
                                           ydata = as.data.frame(datymat_no0sp), 
                                           modelList = gjamControl_rl1) }, 
                    error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    if (is.null(gjam1fit)) {
        tryCatch({ gjam1fit	<-	gjam::gjam(formula = form, 
                                           xdata = as.data.frame(datx), 
                                           ydata = as.data.frame(datymat_no0sp), 
                                           modelList = gjamControl_rl_no_red) }, 
                    error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    eT <- proc.time()
    cT <- eT-sT
    gjam1$fits <- gjam1fit    
    gjam1$computation_time <- cT[[3]]
    gjam1$no0sp <- no0spNames
    gjam1$all_sp <- colnames(datymat)
    

    if (save_model_true) {
        save(gjam1, file = file.path(save_model, "gjam1.RData"))    
    } else {
        return(list(gjam1 = gjam1))
    }
		
}
