#' @title GLM predictions with incorporating parameter uncertainty
#'
#' @param glm_mod A glm model fit object
#' @param new_x New X values
#' @param parameter_uncertainty Boolean
#' @param nsamples Number of samples or replicates
#' @return Predicted values

predict_glm_sdf <-  function(glm_mod,
                             new_x,
                             parameter_uncertainty = TRUE,
                             nsamples = 100)

{



    if (parameter_uncertainty == TRUE) {
      vcovy <- vcov(glm_mod)
      if ( !is.element("sp", colnames(new_x)) ) {
        new_x$sp <- rep(-999, nrow(new_x))  #-999 placeholder, could change na.action
        colnames(new_x)[which(colnames(new_x) == 'sp')] <- names(glm_mod$model)[1]
      }
      X_mod_pred <- model.matrix(glm_mod$formula, data = new_x)
      ranParams <- t(mvtnorm:::rmvnorm(nsamples, coef(glm_mod), sigma = vcovy))
      ranLinPreds <- X_mod_pred %*% ranParams
      ranPreds <- glm_mod$family$linkinv(ranLinPreds)
    } else {
      ranPreds <- predict(glm_mod, type = 'response', newdata = new_x)
      ranPreds <- matrix(rep(ranPreds, times = nsamples), ncol = nsamples)
    }
    
    ranY <- matrix(rbinom(n = length(ranPreds),
                          size = 1,
                          prob = ranPreds),
                   nrow = nrow(ranPreds),
                   ncol = ncol(ranPreds))
    return(ranY)
  }
