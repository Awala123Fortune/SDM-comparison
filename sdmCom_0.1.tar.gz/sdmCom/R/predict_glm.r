#' @title Predict wit a Generalized Linear Model
#'
#' @param targ_model_fits Model fits
#' @param train_dat Training data
#' @param new_dat New data
#' @param nsamples Number of posterior samples
#' @param poly_degree Polynomial degree (1 or 2)
#' @return The predictions

predict_glm  <-    function( targ_model_fits,
                             train_dat,
                             new_dat, 
                             nsamples,
                             load_model,
                             load_model_true, 
                             poly_degree,
                             interactions_x)
                             
    {

    newdatx <- new_dat$x_poly
    newdatx_orig <- newdatx
    #newdatx <- matrix(newdatx, ncol = ncol(newdatx_orig))
    newdatx <- data.frame(newdatx)
    colnames(newdatx) <- colnames(newdatx_orig)
    datymat <- as.matrix(train_dat$y)

    if (load_model_true) {
        glms <- list()
        glms_int <- list()
        targ_model_fits <- list()     
        load(file = file.path(load_model, "glms.RData")) 
        if (interactions_x) {
            load(file = file.path(load_model, "glms_int.RData"))         
        }   
        targ_model_fits$glms <- list(glms = glms,
                                     glms_int = glms_int)
    }

    preds1 <- vector("list", length(targ_model_fits$glms))
    preds2 <- preds1
    names(preds1) <- names(targ_model_fits$glms)
    names(preds2) <- paste0(names(preds1), "_with_param_uncertainty")

    for ( mod in 1:length(targ_model_fits$glms) ) {

        glm_PAs_1 <- array(NA, dim=list(nrow(newdatx), ncol(datymat), nsamples))
        glm_PAs_2 <- array(NA, dim=list(nrow(newdatx), ncol(datymat), nsamples))
        glmod <- targ_model_fits$glms[[mod]]$fits

        if (length(glmod) != 0) {
            for (i in 1:length(glmod)) {
                newdatxs <- newdatx[names(glmod[[i]]$model)[-1]]
                if (!is.null(glmod[[i]])) {       
                    tmp1 <- predict_glm_sdf(glm_mod = glmod[[i]],
                                            new_x = newdatxs,
                                            parameter_uncertainty = TRUE,
                                            nsamples = nsamples)
                    tmp2 <- predict_glm_sdf(glm_mod = glmod[[i]],
                                            new_x = newdatxs,
                                            parameter_uncertainty = FALSE,
                                            nsamples = nsamples)
                } else {
                    tmp1 <- matrix(NA, nrow = nrow(newdatxs), ncol = nsamples)
                    tmp2 <- tmp1
                    for (j in 1:nsamples) {
                        tmp1[,j] <- rbinom(rep(mean(datymat[,i]),
                                               each = nrow(newdatxs)),
                                           1,
                                           rep(mean(datymat[,i]),
                                               each = nrow(newdatxs)))
                        tmp2 <- tmp1
                    }
                }
                glm_PAs_1[,i,] <- tmp1
                glm_PAs_2[,i,] <- tmp2
            }
            preds1[[mod]]$predictions <- glm_PAs_1
            preds2[[mod]]$predictions <- glm_PAs_2
        } else {
            preds1[[mod]]$predictions <- list()        
            preds2[[mod]]$predictions <- list()        
        }
    }
    return(c(preds1, preds2))
}
