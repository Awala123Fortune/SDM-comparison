#' @title Fit a Bayesian Community Model
#'
#' @param dat A list of data matrices (or data frames)
#' @param interactions_x Boolean
#' @param mcmcControl MCMC sampling settings 
#' @param BcControl BayesComm settings
#' @return The model fit object and computation time(s)


fit_bc  <-  function(dat, 
                     poly_degree, 
                     bcControl,
                     mcmcControl,
                     save_model,
                     save_model_true)
    {

    bc1 <- list()
    bc2 <- list()

    if (poly_degree==1) {
        datx <- dat$x            
    }
    if (poly_degree==2) {
        datx <- dat$x_2           
    }

    datymat <- as.matrix(dat$y)
	no0sp <- colSums(datymat) !=0 & colSums(datymat) != nrow(datymat)
	datymat_no0sp <- datymat[,no0sp]

    if ( sum(no0sp) >= nrow(datymat) ) {
        dif <- -(nrow(datymat) - sum(no0sp) - 1)
        drp <- order(colSums(datymat_no0sp))[1:dif]
        datymat_no0sp <- datymat_no0sp[,-drp]
    }
	
	no0spNames <- colnames(datymat_no0sp)

    if (bcControl$environment) {
        sT <- proc.time()    
        bc1fit	<-	BayesComm::BC(Y = datymat_no0sp, 
                                  X = datx, 
                                  model = "environment",
                                  its = mcmcControl$niterTot, 
                                  thin = mcmcControl$thin, 
                                  burn = mcmcControl$nburn)
        eT <- proc.time()
        cT <- eT-sT
        bc1$fits <- bc1fit    
        bc1$computation_time <- cT[[3]]
        bc1$no0sp <- no0spNames
    }

    if (save_model_true) {
        save(bc1, file = file.path(save_model, "bc1.RData"))    
    }    

    if (bcControl$full) {
        sT <- proc.time()    
        bc2fit	<-	BayesComm::BC(Y = datymat_no0sp, 
                                  X = datx, 
                                  model = "full",
                                  its = mcmcControl$niterTot, 
                                  thin = mcmcControl$thin, 
                                  burn = mcmcControl$nburn)
        eT <- proc.time()
        cT <- eT-sT
        bc2$fits <- bc2fit
        bc2$computation_time <- cT[[3]]
        bc2$no0sp <- no0spNames
    }

    if (save_model_true) {
        save(bc2, file = file.path(save_model, "bc2.RData"))    
    }    
    
    if (!save_model_true) {
        return(list(bc1 = bc1, bc2 = bc2))
    }
    
}
