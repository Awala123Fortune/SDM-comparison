#' Subset species based on prevalence
#'
#' @param y A matrix or a data frame of numeric species occurrences (presences and absences)
#' @param prevalence_threshold A numeric threshold for subsetting the species.
#' @return The indexes for the columns in which there are more occurrences than defined with prevalence_threshold
#' @examples
#' set.seed(7)
#' y <- matrix(sample(c(0,1), 100, replace = TRUE), ncol=5)
#' y_subset_inds <- common_sp(y=y, prevalence_threshold = 0.5)
#' y_subset <- y[,y_subset_inds]
#' y_subset
#'
#' @export

common_sp <- function(y, prevalence_threshold = 0.1) {
    
    com_sp <- which((colSums(y)/nrow(y)) >= prevalence_threshold)
    return(com_sp)

}
