#' @title Calibration measure for marginal species occurrence probabilities
#'
#' @param occurrence_probs Occurrence probabilities (from modify_predictions)
#' @param yvalid Validation occurrence data
#' @return Absolute difference between predicted and observed numbers of occurrences in 10 probability bins (each including same number of data points, based on quantiles), averaged over species
#'
#' @details Measure 1C from Norberg et al. (2019)

pm_calibration_prob_bin_mse <- function(occurrence_probs,
                                        yvalid,
                                        as_array) 

{

    if (as_array) {
        prob_bin_mse <- NA
    } else {
        prob_bin_mse <- vector("list", length(occurrence_probs))
        names(prob_bin_mse) <- names(occurrence_probs)
    }

    for ( m in 1:length(occurrence_probs) ) {

        tmp <- vector("list", length(occurrence_probs[[m]]))
        names(tmp) <- names(occurrence_probs[[m]])
    
        for ( f in 1:length(occurrence_probs[[m]]) ) {

            errors <- NA

            for (i in 1:ncol(yvalid)) {

                bins <- NULL
                sptmp <- occurrence_probs[[m]][[f]][,i]
			    bins <- quantile(sptmp, probs=seq(0, 1, 0.1))

    			err <- list()
	    		b1 <- which(sptmp >= bins[1] & sptmp < bins[2])
		
                err[[1]] <- sptmp[b1] - yvalid[b1,i]
                for (b in 2:(length(bins)-2)) {
                    b1 <- which(sptmp >= bins[b] & sptmp < bins[b + 1])	
                    err[[b]] <- (sptmp[b1]-yvalid[b1,i]) / length(b1)
                }

                b1 <- which(sptmp >= bins[length(bins) - 1] & sptmp < bins[length(bins)])	
                err[[length(bins)-1]] <- sptmp[b1] - yvalid[b1,i]
        
                if (length(unlist(err)) == 0) {
                    err <- (sptmp - yvalid[,i]) / length(sptmp)
                }			
                errors <- c(errors, mean(sqrt(unlist(err)^2)))
                                
            }

			tmp[[f]] <- mean(errors[-1])				          
        }
        
        if (as_array) {
            prob_bin_mse <- rbind(prob_bin_mse,
                                  cbind(names(occurrence_probs)[m], 
                                  names(tmp), 
                                  unlist(tmp))) 
        } else {
            prob_bin_mse[[m]] <- tmp
        }

    }

    if (as_array) {
        prob_bin_mse <- prob_bin_mse[-1,]
    }

    return(calibration_prob_bin_mse = prob_bin_mse)
}
