#' @title Fit Boosted Regression Tree
#'
#' @param dat A list of data matrices (or data frames)
#' @param brtControl Boosted Regression Tree tuning parameter settings 
#' @return The model fit object and computation time(s)

fit_brt <- function(dat, 
                    brtControl, 
                    save_model, 
                    save_model_true)

    {

    vals <- cbind(rep(brtControl$tcs, each = length(brtControl$lrs)),
                  rep(brtControl$lrs, times = length(brtControl$tcs)))

    brts <- list()
    brtfits <- vector("list", ncol(dat$y)) 
    names(brtfits) <- colnames(dat$y)
			
	gbmNtrees <- matrix(NA, nrow=ncol(dat$y))

	sT <- proc.time()
    for (i in 1:ncol(dat$y)) {

		gbms <- list()
		gbmErr <- matrix(NA, nrow=nrow(vals))

		for (v in 1:nrow(vals)){
		    gbmod	<- NULL
			tryCatch({
			gbmod	<- gbm.step(data=data.frame(cbind(dat$y[,i],dat$x)), 
			                    gbm.x = c(2:ncol(cbind(dat$y[,i],dat$x))), 
			                    gbm.y = 1, 
			                    prev.stratify = TRUE,
						        family = "bernoulli", 
						        plot.main=FALSE, 
						        plot.folds=FALSE, 
						        learning.rate=vals[v,2], 
						        tree.complexity=vals[v,1],
						        silent = TRUE)

				if (!is.null(gbmod)){
					gbms[[v]] <- gbmod
					gbmErr[v,] <- gbmod$cv.statistics$deviance.mean
				}
			}, error=function(e){ err <- paste("ERROR:",conditionMessage(e))
                                                    return(err) })
		}

		if (all(is.na(gbmErr))){
			brtfits[[i]] <- NA
		} else {
			brtfits[[i]] <- gbms[[which(gbmErr==min(gbmErr, na.rm=T), arr.ind=TRUE)[1]]]
		}
    }
    eT <- proc.time()
    cT <- eT-sT

    brts$fits <- brtfits
    brts$computation_time <- cT[[3]]

    if (save_model_true) {
        save(brts, file = file.path(save_model, "brts.RData"))    
    } else {
        return(list(brts = brts))
    }
    
}

