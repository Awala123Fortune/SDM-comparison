#' @title Predict with a Bayesian Community Model
#'
#' @param targ_model_fits Model fits
#' @param train_dat Training data
#' @param new_dat New data
#' @param nsamples Number of posterior samples
#' @param poly_degree Polynomial degree (1 or 2)
#' @return The predictions

predict_bc  <-  function(targ_model_fits,
                         train_dat,
                         new_dat,
                         nsamples,
                         load_model, 
                         poly_degree,
                         load_model_true) {
            
    if (poly_degree==1) {
        newdatx <- new_dat$x            
    }
    if (poly_degree==2) {
        newdatx <- new_dat$x_2           
    }
    datymat <- as.matrix(train_dat$y)

    if (load_model_true) {
        targ_model_fits <- list()
        load(file = file.path(load_model, "bc1.RData"))    
        load(file = file.path(load_model, "bc2.RData"))    
        targ_model_fits$bcs <- list(bc1 = bc1, bc2 = bc2)
    }

    preds <- vector("list", length(targ_model_fits$bcs)) 
    names(preds) <- names(targ_model_fits$bcs)

    for (mod in 1:length(targ_model_fits$bcs)) {
    
        bc <- targ_model_fits$bcs[[mod]]

        bc_pred  <- BayesComm:::predict.bayescomm(bc$fits, 
                                                 newdata = newdatx, 
                                                 type = "terms")

        tmp <- rbinom(bc_pred, 1, bc_pred)

        bc_PAs <- array(tmp,
                    dim=list(dim(bc_pred)[1],
                             dim(bc_pred)[2],
                             dim(bc_pred)[3]))

        if (length(bc$no0sp) != length(colnames(datymat))) {
            bc_pred_w0sp <- array(NA, dim = list(nrow(newdatx),
                                                 ncol(datymat),
                                                 dim(bc_pred)[3]),
                                      dimnames = list(1:nrow(newdatx),
                                                      colnames(datymat),
                                                      1:dim(bc_pred)[3]))			

            for (i in 1:dim(bc_pred)[3]) {
                bc_pred_w0sp[,,i]<-rbinom(colMeans(datymat),
                                          1,
                                          colMeans(datymat))
                bc_pred_w0sp[,bc$no0sp,i] <- bc_PAs[,,i]
            }
            bc_PAs <- bc_pred_w0sp
        }

		set.seed(123)
		smplREPs <- sample(1:dim(bc_PAs)[3], nsamples, replace = TRUE)
		bc_PAs <- bc_PAs[,,smplREPs]
        
        preds[[mod]]$predictions <- bc_PAs
        preds[[mod]]$no0sp <- bc$no0sp
        preds[[mod]]$model_type <- bc$fits$call$model
    }

    return(list(bc1 = preds[[1]], bc2 = preds[[2]]))

}
