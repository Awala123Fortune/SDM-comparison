#' Sample the data (rows)
#'
#' @param y The response matrix or data frame
#' @param x The explanatory matrix or data frame
#' @param xy The spatial structure matrix or data frame
#' @param sampsize The size of the sample (number of rows)
#' @param seed Seed for random number generation when sampling the data (rows)
#' @return A list of subsampled matrices or data frames
#' @examples
#' y <- matrix(sample(c(0,1), 300, replace = TRUE), ncol = 3)
#' x <- matrix(rnorm(400), ncol = 4)
#' xy <- matrix(rnorm(200), ncol = 2)
#' data_sample <- sample_rows(y = y, x = x, xy = xy, sampsize = 50, seed = 1)
#'
#' @export

sample_rows <- function (x, y, xy = NULL, sampsize, seed = 7) {

    if (nrow(x)!=nrow(y)) {
        stop("x and y matrices have different numbers of rows")
    }

    set.seed(seed)
    samp <- sample(1:nrow(y), sampsize, replace = FALSE)

    y_s <- y[samp,]
    x_s <- x[samp,]
    xy_s <- xy
    
    if (!is.null(xy)) {
        xy_s <- xy[samp,]
    }    
    return(list(y=y_s, x=x_s, xy=xy_s))
}
