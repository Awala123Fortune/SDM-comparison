#' @title Fit a Hierarchical or a Stacked Community Model
#'
#' @param dat A list of data matrices (or data frames)
#' @param poly_degree Polynomial degree (1 or 2)
#' @param interactions_x Boolean
#' @param spatial Boolean
#' @param mcmcControl MCMC sampling settings 
#' @param HmscControl HMSC specific settings
#' @return The model fit object(s) and computation time(s)

fit_hmsc      <- function(dat, 
                          poly_degree, 
                          interactions_x, 
                          spatial,
                          mcmcControl,
                          hmscControl,
                          save_model,
                          save_model_true)
    {

    hmsc1 <- list(spatial = FALSE, community = TRUE)
    hmsc1_int <- list(spatial = FALSE, community = TRUE)
    hmsc2 <- list(spatial = FALSE, community = TRUE)
    hmsc2_int <- list(spatial = FALSE, community = TRUE)
    hmsc3 <- list(spatial = TRUE, community = TRUE)
    hmsc3_int <- list(spatial = TRUE, community = TRUE)

    hmsc1_ss <- list(spatial = FALSE, stacked = TRUE)
    hmsc1_int_ss <- list(spatial = FALSE, stacked = TRUE)
    hmsc3_ss <- list(spatial = TRUE, stacked = TRUE)
    hmsc3_int_ss <- list(spatial = TRUE, stacked = TRUE)

    niter <- mcmcControl$niterTot - mcmcControl$nburn
    nsampls <- (mcmcControl$niterTot - mcmcControl$nburn) / mcmcControl$thin

    datymat <- as.matrix(dat$y)

    studyDes <- matrix(NA, nrow(dat$x), 1)
    studyDes[,1] <- sprintf('site_%.3d', 1:nrow(dat$x)) 
    studyDes <- as.data.frame(studyDes)
    colnames(studyDes) <- "Sites"
    studyDes[,1] <- as.factor(studyDes[,1])
    rl <- matrix(1:nrow(studyDes), ncol=1)
    rownames(rl) <- studyDes[,1]
    rLs <- list("Sites" = Hmsc::HmscRandomLevel(units = rl))
     
    if (spatial) {
        sites <- levels(studyDes[,1])
        nsites <- length(sites)
        xy <- matrix(0, nrow = nsites, ncol = 2) 
        for (i in 1:nsites){
            rows <- studyDes[,1]==sites[[i]] 
            xy[i,1] <- mean(dat$xy[rows,1])
            xy[i,2] <- mean(dat$xy[rows,2]) 
        }
        colnames(xy) <- c("xy1","xy2")
        sRL <- xy
        rownames(sRL) <- sites
        rLs_s <- list("Sites" = Hmsc::HmscRandomLevel(sData = sRL)) 
    }
    
    if (interactions_x) {
        models <- c('no_ints', 'w_ints')
    } else {
        models <- 'no_ints'
    }

    for (mod in models) {

        if (mod=='no_ints') {
            if (poly_degree==1) {
                datx <- dat$x            
            }
            if (poly_degree==2) {
                datx <- dat$x_2           
            }
        }
        if (mod=='w_ints') {
            if (poly_degree==1) {
                datx <- dat$x_1_int            
            }
            if (poly_degree==2) {
                datx <- dat$x_poly
            }
        }

        if (hmscControl$stacked) {
            #stacked
            #1 basic model
            sT <- proc.time()
            hmsc1fits_ss <- list()
            for (i in 1:ncol(datymat)) {
                hmscObj1 <- NULL
                hmscObj1	<-	Hmsc::Hmsc(Y = matrix(datymat[,i], ncol=1), 
                                           X = datx,
                                           XScale = TRUE,
                                           distr = "probit")
                #Hmsc::setPriors(hmscObj1)
                hmsc1fits_ss[[i]] <- Hmsc::sampleMcmc(hmscObj1, 
                                                      samples = niter, 
                                                      thin = mcmcControl$thin, 
                                                      adaptNf = hmscControl$nadapt,
                                                      transient = mcmcControl$nburn, 
                                                      nChains = hmscControl$nchains)
            }
            eT <- proc.time()
            cT <- eT-sT
        
            if (mod=='no_ints') {
                hmsc1_ss$fits <- hmsc1fits_ss
                hmsc1_ss$computation_time <- cT[[3]]
            }
            if (mod=='w_ints') {
                hmsc1_int_ss$fits <- hmsc1fits_ss
                hmsc1_int_ss$computation_time <- cT[[3]]
            }

            if (spatial) {
               #3 model with shared responses to environment and spatial structure
                sT <- proc.time()
                hmsc3fits_ss <- list()
                for (i in 1:ncol(datymat)) {
                    hmscObj3 <- NULL
                    hmscObj3	<-	Hmsc::Hmsc(Y = matrix(datymat[,i], ncol=1), 
                                               X = datx,
                                               XScale = TRUE,
                                               studyDesign = studyDes,
                                               ranLevels = rLs, 
                                               ranLevelsUsed = "Sites",
                                               distr = "probit")
                    #Hmsc::setPriors(hmscObj3)
                    sT <- proc.time()
                    hmsc3fits_ss[[i]] <- Hmsc::sampleMcmc(hmscObj3, 
                                                          samples = niter, 
                                                          thin = mcmcControl$thin, 
                                                          adaptNf = hmscControl$nadapt,
                                                          transient = mcmcControl$nburn, 
                                                          nChains = hmscControl$nchains)
                    eT <- proc.time()
                    cT <- eT-sT
        
                    if (mod=='no_ints') {
                        hmsc3_ss$fits <- hmsc3fits_ss
                        hmsc3_ss$computation_time <- cT[[3]]
                    }
                    if (mod=='w_ints') {
                        hmsc3_int_ss$fits <- hmsc3fits_ss
                        hmsc3_int_ss$computation_time <- cT[[3]]
                    }
                }
            }
        }
        
        if (hmscControl$community) {
            #community
            #1 model with shared responses to environment, no associations btwn species
            hmscObj1	<-	Hmsc::Hmsc(Y = datymat, 
                                       X = datx,
                                       XScale = TRUE,
                                       distr = "probit")
            #Hmsc::setPriors(hmscObj1)
            sT <- proc.time()
            hmsc1fit <- Hmsc::sampleMcmc(hmscObj1, 
                                         samples = niter, 
                                         thin = mcmcControl$thin, 
                                         adaptNf = hmscControl$nadapt,
                                         transient = mcmcControl$nburn, 
                                         nChains = hmscControl$nchains)
            eT <- proc.time()
            cT <- eT-sT

            if (mod=='no_ints') {
                hmsc1$fits <- hmsc1fit
                hmsc1$computation_time <- cT[[3]]
            }
            if (mod=='w_ints') {
                hmsc1_int$fits <- hmsc1fit
                hmsc1_int$computation_time <- cT[[3]]
            }

            #2 model with shared responses to environment and site level associations btwn species
            hmscObj2	<-	Hmsc::Hmsc(Y = datymat, 
                                       X = datx,
                                       XScale = TRUE,
                                       studyDesign = studyDes,
                                       ranLevels = rLs, 
                                       ranLevelsUsed = "Sites",
                                       distr = "probit")

            #Hmsc::setPriors(hmscObj2)
            sT <- proc.time()
            hmsc2fit <- Hmsc::sampleMcmc(hmscObj2, 
                                        samples = niter, 
                                        thin = mcmcControl$thin, 
                                        adaptNf = hmscControl$nadapt,
                                        transient = mcmcControl$nburn, 
                                        nChains = hmscControl$nchains)

            eT <- proc.time()
            cT <- eT-sT

            if (mod=='no_ints') {
                hmsc2$fits <- hmsc2fit
                hmsc2$computation_time <- cT[[3]]
            }
            if (mod=='w_ints') {
                hmsc2_int$fits <- hmsc2fit
                hmsc2_int$computation_time <- cT[[3]]
            }

            if (spatial) {
               #3 model with shared responses to environment and spatial structure
                hmscObj3	<-	Hmsc::Hmsc(Y = datymat, 
                                           X = datx,
                                           XScale = TRUE,
                                           studyDesign = studyDes,
                                           ranLevels = rLs_s, 
                                           ranLevelsUsed = "Sites",
                                           distr = "probit")

                #Hmsc::setPriors(hmscObj3)
                sT <- proc.time()
                hmsc3fit <- Hmsc::sampleMcmc(hmscObj3, 
                                             samples = niter, 
                                             thin = mcmcControl$thin, 
                                             adaptNf = hmscControl$nadapt,
                                             transient = mcmcControl$nburn, 
                                             nChains = hmscControl$nchains)

                eT <- proc.time()
                cT <- eT-sT

                if (mod=='no_ints') {
                    hmsc3$fits <- hmsc3fit
                    hmsc3$computation_time <- cT[[3]]
                }
                if (mod=='w_ints') {
                    hmsc3_int$fits <- hmsc3fit
                    hmsc3_int$computation_time <- cT[[3]]
                }
            }
        }
    }

    if (save_model_true) {
        save(hmsc1, file = file.path(save_model, "hmsc1.RData"))    
        save(hmsc1_int, file = file.path(save_model, "hmsc1_int.RData"))    
        save(hmsc2, file = file.path(save_model, "hmsc2.RData"))    
        save(hmsc2_int, file = file.path(save_model, "hmsc2_int.RData"))    
        save(hmsc3, file = file.path(save_model, "hmsc3.RData"))    
        save(hmsc3_int, file = file.path(save_model, "hmsc3_int.RData"))    
        save(hmsc1_ss, file = file.path(save_model, "hmsc1_ss.RData"))    
        save(hmsc1_int_ss, file = file.path(save_model, "hmsc1_int_ss.RData"))    
        save(hmsc3_ss, file = file.path(save_model, "hmsc3_ss.RData"))    
        save(hmsc3_int_ss, file = file.path(save_model, "hmsc3_int_ss.RData"))    
    } else {
        return(list(hmsc1 = hmsc1, 
                    hmsc1_int = hmsc1_int, 
                    hmsc2 = hmsc2, 
                    hmsc2_int = hmsc2_int, 
                    hmsc3 = hmsc3, 
                    hmsc3_int = hmsc3_int,
                    hmsc1_ss = hmsc1_ss,
                    hmsc1_int_ss = hmsc1_int_ss,
                    hmsc3_ss = hmsc3_ss,
                    hmsc3_int_ss = hmsc3_int_ss))
    }
    
}
