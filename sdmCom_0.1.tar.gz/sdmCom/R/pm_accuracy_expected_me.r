#' @title Accuracy measure for marginal species occurrence probabilities
#'
#' @param occurrence_probs Occurrence probabilities (from modify_predictions)
#' @param yvalid Validation occurrence data
#' @return Absolute difference between expected (probability) and observed (0/1) occurrence, averaged over species and sites
#'
#' @details Measure 1A from Norberg et al. (2019)

pm_accuracy_expected_me <- function(occurrence_probs,
                                    yvalid,
                                    as_array) 

{

    if (as_array) {
        expctME <- NA
    } else {
        expctME <- vector("list", length(occurrence_probs))
        names(expctME) <- names(occurrence_probs)    
    }
    
    for ( m in 1:length(occurrence_probs) ) {

        tmp <- vector("list", length(occurrence_probs[[m]]))
        names(tmp) <- names(occurrence_probs[[m]])

        for ( f in 1:length(occurrence_probs[[m]]) ) {

            tmp[[f]] <- mean(unlist(abs(occurrence_probs[[m]][[f]] - yvalid)))
        
        }
        
        if (as_array) {
            expctME <- rbind(expctME,
                             cbind(names(occurrence_probs)[m], 
                                   names(tmp), 
                                   unlist(tmp))) 
        } else {
            expctME[[m]] <- tmp
        }

    }

    if (as_array) {
        expctME <- expctME[-1,]
    }

    return(accuracy_expected_me = expctME)

}
