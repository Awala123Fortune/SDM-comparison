#' @title Fit a Bayesian Regression Model
#'
#' @param dat A list of data matrices (or data frames)
#' @param interactions_x Boolean
#' @param mcmcControl MCMC sampling settings 
#' @return The model fit object and computation time(s)

fit_boral  <-  function(dat, 
                        poly_degree, 
                        mcmcControl, 
                        save_model,
                        save_model_true,
                        boralControl)
    {

    boral1 <- list()
    boral2 <- list()

    if (poly_degree==1) {
        datx <- dat$x            
    }
    if (poly_degree==2) {
        datx <- dat$x_2           
    }

    datymat <- as.matrix(dat$y)

    boralMcmcControl <- list(n.burnin=mcmcControl$nburn,
	        			     n.iteration=mcmcControl$niterTot,
			        	     n.thin=mcmcControl$thin)

    if ( is.null(boralControl$jags_model_dir) ) {
            boralControl$jags_model_dir <- "."
            print("Since there is no directory for saving model object, jags model description file fir boral is saved to the current working directory")
    }

    sT <- proc.time()    
	brl1fit <-	boral::boral(y = datymat, 
					         X = datx, 
                             num.lv = 0,
                             family = "binomial", 
                             calc.ics = FALSE, 
                             mcmc.control = boralMcmcControl, 
                             save.model = TRUE,
                             model.name = file.path(boralControl$jags_model_dir, "brl1model.txt"))
    eT <- proc.time()
    cT <- eT-sT
    boral1$fits <- brl1fit    
    boral1$computation_time <- cT[[3]]
						  
    sT <- proc.time()    
	brl2fit	<-	boral::boral(y = datymat,
					         X = datx, 
					         num.lv = 2, 
			  		         family = "binomial", 
			  		         calc.ics = FALSE,
			  		         mcmc.control = boralMcmcControl, 
			  		         save.model = TRUE,
                             model.name = file.path(boralControl$jags_model_dir, "brl2model.txt"))
    eT <- proc.time()
    cT <- eT-sT
    boral2$fits <- brl2fit    
    boral2$computation_time <- cT[[3]]

    if (save_model_true) {
        save(boral1, file = file.path(save_model, "boral1.RData"))    
        save(boral2, file = file.path(save_model, "boral2.RData"))    
    } else {
        return(list(boral1 = boral1, boral2 = boral2))
    }

}
