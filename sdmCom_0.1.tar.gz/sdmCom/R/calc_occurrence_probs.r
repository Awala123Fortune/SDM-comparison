#' @title Calculate species occurrence probabilities from predicted presences/absences
#'
#' @param predictions An array of predicted presences/absences
#' @return Species occurrence probabilities

calc_occurrence_probs <- function (predictions,
                                   avoid_singular = FALSE) 
    
{

    if (avoid_singular) {
        print("To avoid singular cases due to the prediction being exactly 0 or 1, we transformed the probabilities by first multiplying them by 0.99 and then adding 0.005, so that they were in the range [0.005, 0.995] instead of the range [0,1]")
    }

    spOccProbs <- vector("list", length(predictions$predictions))
    names(spOccProbs) <- names(predictions$predictions)
    
    for ( m in 1:length(predictions$predictions) ) {

        tmp <- vector("list", length(predictions$predictions[[m]]))
        names(tmp) <- names(predictions$predictions[[m]])

        for (f in 1:length(predictions$predictions[[m]]) ) {

    		tmp[[f]] <- apply(predictions$predictions[[m]][[f]]$predictions, 
    		                  c(1,2), 
    		                  mean)
    		if (avoid_singular) {
    		    tmp[[f]] <- (tmp[[f]] * 0.99) + 0.005  	
    		}
        }   
         		
        spOccProbs[[m]] <- tmp	
    }

    return(spOccProbs)

}
