#' @title Calculate species richness from predicted presences/absences
#'
#' @param predictions An array of predicted presences/absences
#' @return Species richness

calc_sp_richness <- function (predictions, yvalid) 

{

    sp_rich <- vector("list", length(predictions$predictions))
    names(sp_rich) <- names(predictions$predictions)
    
    for ( m in 1:length(predictions$predictions) ) {

        tmp <- vector("list", length(predictions$predictions[[m]]))
        names(tmp) <- names(predictions$predictions[[m]])

        for (f in 1:length(predictions$predictions[[m]]) ) {

    		tmp[[f]] <- apply(predictions$predictions[[m]][[f]]$predictions, 
    		                  3, 
    		                  rowSums,
    		                  na.rm = TRUE)
    		                  
        }   
         		
        sp_rich[[m]] <- tmp	
    }

    sp_rich_valid <- rowSums(yvalid)
    
    return(list(predicted = sp_rich,
                validation = sp_rich_valid))

}
