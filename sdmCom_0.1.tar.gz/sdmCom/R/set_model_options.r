#' @title Set model options to defaults
#'
#' @return A list of options for models
#' @examples
#' opts <- set_model_options()
#'
#' @export

set_model_options <- function (model_options,
                               models,
                               save_model)
{

    print("Model options checked, using defaults for those missing (see ?set_model_options)")

    if ('bc' %in% models | 'boral' %in% models | 'hmsc' %in% models | 'gjam' %in% models) {
        if( is.null(model_options$mcmcControl) ) {
        mcmcControl <- list(niterTot = 500,
                            nburn = 300,
                            thin = 1)
        } else {
            mcmcControl <- model_options$mcmcControl
        }
    } else {
        mcmcControl <- NULL
    }
    
    if('bc' %in% models) {
        if (is.null(model_options$bcControl)) {
            bcControl <- list(environment = TRUE,
                            full = TRUE)
        } else {
            bcControl <- model_options$bcControl
        } 
    } else {
        bcControl <- NULL
    }

    if('boral' %in% models) {
        if (is.null(model_options$boralControl)) {
            boralControl <- list(jags_model_dir = save_model)
        } else {
            boralControl <- model_options$boralControl
        } 
    } else {
        boralControl <- NULL
    }

    if('brt' %in% models) {
        if (is.null(model_options$brtControl)) {
            brtControl <- list(tcs = c(2:5),
                               lrs = c(0.1^(1:4)))
        } else {
            brtControl <- model_options$brtControl
        } 
    } else {
        brtControl <- NULL
    }

    if('hmsc' %in% models) {
        if (is.null(model_options$hmscControl)) {
            hmscControl <- list(stacked = TRUE,
                                community = TRUE,
                                nadapt = 100,
                                nchains = 1)
        } else {
            hmscControl <- model_options$hmscControl
        } 
    } else {
        hmscControl <- NULL
    }

    if('rf' %in% models) {
        if (is.null(model_options$rfControl)) {
            rfControl <- list(ntrees = seq(500, 2000, by = 500),
                              mtrys = 2:ceiling(ncol(datax)/2),
                              nodszs = c(1,2,5,10))
        } else {
            rfControl <- model_options$rfControl
        } 
    } else {
        rfControl <- NULL
    }

    return( list( mcmcControl = mcmcControl,
                  bcControl = bcControl,
                  boralControl = boralControl,
                  brtControl = brtControl,
                  hmscControl = hmscControl,
                  rfControl = rfControl ))

}
