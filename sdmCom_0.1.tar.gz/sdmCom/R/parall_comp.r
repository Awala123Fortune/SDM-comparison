#' Define parallel computing settings
#'
#' @param ncores How maby computational units you want to use at maximun
#' @examples
#' parall_comp(ncores = 2)
#'
#' @export

parall_comp <- function(ncores = 1) {

   os <- get_os()

    if (os=="osx"|os=="unix") { 
        doMC::registerDoMC(cores=ncores)
    }
#    if (os=="win") {
#        registerDoParallel(cl=makeCluster(ncores))
#    }

}
