#' @title Precision measure for species richness and community composition
#'
#' @param species_richness Species richness (from modify_predictions)
#' @param community_composition Community composition (from modify_predictions)
#' @return Average of predictive standard deviations
#'
#' @details Measures 2D and 3D from Norberg et al. (2019)

pm_precision_sd <- function(species_richness = NULL,
                            community_composition = NULL,
                            as_array) 

{
    sp_rich_sd <- NULL
    comm_comp_sd <- NULL
    
    if (!is.null(species_richness)) {

        if (as_array) {
            sp_rich_sd <- NA
        } else {
            sp_rich_sd <- vector("list", length(species_richness$predicted))
            names(sp_rich_sd) <- names(species_richness$predicted)
        }
    
        for ( m in 1:length(species_richness$predicted) ) {

            tmp <- vector("list", length(species_richness$predicted[[m]]))
            names(tmp) <- names(species_richness$predicted[[m]])
    
            for ( f in 1:length(species_richness$predicted[[m]]) ) {

                tmp[[f]] <- mean( apply(species_richness$predicted[[m]][[f]], 
                                        1, 
                                        sd) )
                                      
            }

            if (as_array) {
                sp_rich_sd <- rbind(sp_rich_sd,
                                    cbind(names(species_richness$predicted)[m], 
                                    names(tmp), 
                                    unlist(tmp)))
            } else {
                sp_rich_sd[[m]] <- tmp
            }

        }
        if (as_array) {
            sp_rich_sd <- matrix(sp_rich_sd[-1,], ncol = 3)
        }
    }

    if (!is.null(community_composition)) {

        if (as_array) {        
            beta_sim_sd <- NA
            beta_sne_sd <- NA
            beta_sor_sd <- NA
        } else {
            beta_sim_sd <- vector("list", length(community_composition$beta_sim))
            names(beta_sim_sd) <- names(community_composition$beta_sim)
        
            beta_sne_sd <- vector("list", length(community_composition$beta_sne))
            names(beta_sne_sd) <- names(community_composition$beta_sne)
        
            beta_sor_sd <- vector("list", length(community_composition$beta_sor))
            names(beta_sor_sd) <- names(community_composition$beta_sor)
        }

        for ( m in 1:length(community_composition$beta_sim) ) {

            tmp_sim <- vector("list", length(community_composition$beta_sim[[m]]))
            names(tmp_sim) <- names(community_composition$beta_sim[[m]])

            tmp_sne <- vector("list", length(community_composition$beta_sne[[m]]))
            names(tmp_sne) <- names(community_composition$beta_sne[[m]])

            tmp_sor <- vector("list", length(community_composition$beta_sor[[m]]))
            names(tmp_sor) <- names(community_composition$beta_sor[[m]])

            for ( f in 1:length(community_composition$beta_sim[[m]]) ) {

                tmp_sim[[f]] <- mean( apply(community_composition$beta_sim[[m]][[f]], 
                                            1, 
                                            sd) )
                                                                                
                tmp_sne[[f]] <- mean( apply(community_composition$beta_sne[[m]][[f]], 
                                            1, 
                                            sd) )

                tmp_sor[[f]] <- mean( apply(community_composition$beta_sor[[m]][[f]], 
                                            1, 
                                            sd) )

            }

            if (as_array) {
                beta_sim_sd <- rbind(beta_sim_sd,
                                          cbind(names(community_composition$beta_sim)[m], 
                                          names(tmp_sim), 
                                          unlist(tmp_sim))) 
                beta_sne_sd <- rbind(beta_sne_sd,
                                          cbind(names(community_composition$beta_sne)[m], 
                                          names(tmp_sne), 
                                          unlist(tmp_sne))) 
                beta_sor_sd <- rbind(beta_sor_sd,
                                          cbind(names(community_composition$beta_sor)[m], 
                                          names(tmp_sor), 
                                          unlist(tmp_sor))) 
            } else {
                beta_sim_sd[[m]] <- tmp_sim
                beta_sne_sd[[m]] <- tmp_sne
                beta_sor_sd[[m]] <- tmp_sor
            }

        }
        if (as_array) {
            comm_comp_sd <- cbind(beta_sim_sd[-1,3],
                                  beta_sne_sd[-1,3],
                                  beta_sor_sd[-1,3])            
        } else {
            comm_comp_sd <- list(beta_sim_sd = beta_sim_sd,
                                 beta_sne_sd = beta_sne_sd,
                                 beta_sor_sd = beta_sor_sd)
        }
    }

    if (as_array) {
        res_arr <- cbind(sp_rich_sd, comm_comp_sd)
        colnames(res_arr) <- c("modelling framework",
                               "model variant",
                               "sp_rich_sd", 
                               "beta_sim_sd",
                               "beta_sne_sd",
                               "beta_sor_sd")
        return( res_arr )
    } else {
        return(list(sp_richness_sd = sp_rich_sd,
                    community_composition_sd = comm_comp_sd))
    }

}
