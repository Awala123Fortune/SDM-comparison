#' @title Discrimination measure for marginal species occurrence probabilities
#'
#' @param occurrence_probs Occurrence probabilities (from modify_predictions)
#' @param yvalid Validation occurrence data
#' @return Area Under Curve (AUC), averaged over species
#'
#' @details Measure 1B from Norberg et al. (2019)

pm_discrimination_auc <- function(occurrence_probs,
                                  yvalid,
                                  as_array) 

{

    if (as_array) {
        aucs <- NA
    } else {
        aucs <- vector("list", length(occurrence_probs))
        names(aucs) <- names(occurrence_probs)
    }

    for ( m in 1:length(occurrence_probs) ) {

        tmp <- vector("list", length(occurrence_probs[[m]]))
        names(tmp) <- names(occurrence_probs[[m]])
    
        for ( f in 1:length(occurrence_probs[[m]]) ) {

            tmp1 <- matrix(NA, nrow = 1, ncol = ncol(yvalid))
            
            for (i in 1:ncol(yvalid)) {

                tryCatch({ ( tmp1[,i] <- pROC:::roc(predictor = occurrence_probs[[m]][[f]][,i],
                                                     response = yvalid[,i])$auc ) },
                             error=function(e){ err <- paste("ERROR:",conditionMessage(e))
                                                            return(err) })
            }                                              
			tmp[[f]] <- mean(tmp1, na.rm = TRUE)				          
        }

        if (as_array) {
            aucs <- rbind(aucs,
                          cbind(names(occurrence_probs)[m], 
                                names(tmp), 
                                unlist(tmp))) 
        } else {
            aucs[[m]] <- tmp
        }

    }

    if (as_array) {
        aucs <- aucs[-1,]
    }


    return(discrimination_auc = aucs)
}
