#' Subset species based on threshold
#'
#' @param y The (numeric) response matrix or data frame
#' @param threshold Minimun number of occurrences
#' @return A subsampled matrix or data frame of occurrences
#' @examples
#' y <- matrix(sample(c(0,1), 300, replace = TRUE), ncol = 3)
#' y_sub <- subset_sp(y = y, threshold = 1)
#'
#' @export

subset_sp <- function(y, threshold = 1) {

    absent <- which(colSums(y) < threshold)
	absent <- as.numeric(unlist(absent))
	spSel <- 1:ncol(y)
	if (sum(absent) != 0) { 
		spSel <- spSel[-absent]
	}	
	return(spSel)
}
