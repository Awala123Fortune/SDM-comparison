#' @title Create ensembles of predictions from multiple model variants
#'
#' @param ensemble A list of lists defining the ensemble (see Details and Examples)
#' @param predictions A predict_sdmcom object
#' @param nsamples Total number of samples wanted
#' @return Selected performance measure values
#'
#' @export

create_ensembles <- function(ensembles,
                             predictions,
                             nsamples) {

    ens_preds <- list()
    ens_preds$predictions <- list()
    ens_preds$predictions$ENS <- list()
    for (i in 1:length(ensembles)) {
        ens_preds$predictions$ENS[[i]] <- list()
        ens_preds$predictions$ENS[[i]]$predictions <- sdmCom:::create_ensemble(ensemble = ensembles[[i]],
                                                                               predictions = predictions,
                                                                               nsamples = nsamples)
    }
    names(ens_preds$predictions$ENS) <- names(ensembles)

    return(ens_preds)
}
