#' @title Calculate community composition from predicted presences/absences
#'
#' @param predictions An array of predicted presences/absences
#' @return Community composition (see ?betapart for details)

calc_betapart <- function (predictions,
                           yvalid,
                           n_of_site_pairs = 300,
                           seed = NULL) 

{

    if ( !is.null(seed) & is.numeric(seed) ) {
        set.seed(seed)
    }
    sitecombs <- combn(1:dim(predictions$predictions[[1]][[1]]$predictions)[1], 2)   
    selsites <- sitecombs[, sample(1:ncol(sitecombs), 
                            n_of_site_pairs, 
                            replace = TRUE)]


    beta_sim <- vector("list", length(predictions$predictions))
    names(beta_sim) <- names(predictions$predictions)
    beta_sne <- vector("list", length(predictions$predictions))
    names(beta_sne) <- names(predictions$predictions)
    beta_sor <- vector("list", length(predictions$predictions))
    names(beta_sor) <- names(predictions$predictions)

    beta_valid <- matrix(NA, 
                         nrow = n_of_site_pairs, 
                         ncol = 3)

    for ( m in 1:length(predictions$predictions) ) {

       tmp2_sim <- vector("list", length(predictions$predictions[[m]]))
       names(tmp2_sim) <- names(predictions$predictions[[m]])
       tmp2_sne <- vector("list", length(predictions$predictions[[m]]))
       names(tmp2_sne) <- names(predictions$predictions[[m]])
       tmp2_sor <- vector("list", length(predictions$predictions[[m]]))
       names(tmp2_sor) <- names(predictions$predictions[[m]])                             

        for (f in 1:length(predictions$predictions[[m]]) ) {

            tmp_sim <- matrix(NA, 
                             nrow = n_of_site_pairs, 
                             ncol = dim(predictions$predictions[[1]][[1]]$predictions)[3])
            tmp_sne <- matrix(NA, 
                             nrow = n_of_site_pairs, 
                             ncol = dim(predictions$predictions[[1]][[1]]$predictions)[3])
            tmp_sor <- matrix(NA, 
                             nrow = n_of_site_pairs, 
                             ncol = dim(predictions$predictions[[1]][[1]]$predictions)[3])

            for (p in 1:ncol(selsites)) {
                p1 <- p
                p2 <- p
                tmp1 <- unlist(betapart::beta.pair(rbind(predictions$predictions[[m]][[f]]$predictions[selsites[1,p1],,1],
                                                         predictions$predictions[[m]][[f]]$predictions[selsites[2,p2],,1])))
            
                for (i in 2:dim(predictions$predictions[[1]][[1]]$predictions)[3]) {
                
                    tmp1 <- rbind(tmp1, 
                                  unlist(betapart::beta.pair(rbind(predictions$predictions[[m]][[f]]$predictions[selsites[1,p1],,i],
                                                                   predictions$predictions[[m]][[f]]$predictions[selsites[2,p2],,i]))))
                }
                tmp1 <- data.frame(tmp1)
                tmp_sim[p,] <- tmp1$beta.sim
                tmp_sne[p,] <- tmp1$beta.sne
                tmp_sor[p,] <- tmp1$beta.sor
                
                if (m==1 & f==1) {
                    beta_valid[p,] <- unlist(betapart::beta.pair(rbind(yvalid[selsites[1,p1],],
                                                                       yvalid[selsites[2,p2],])))
                }
            }
            tmp_sim[which(is.nan(tmp_sim))] <- 0.995
            tmp_sne[which(is.nan(tmp_sne))] <- 0.005
            tmp_sor[which(is.nan(tmp_sor))] <- 0.995
            tmp2_sim[[f]] <- tmp_sim
            tmp2_sne[[f]] <- tmp_sne
            tmp2_sor[[f]] <- tmp_sor
            if (m==1 & f==1) {
                beta_valid[which(is.nan(beta_valid[,1])),1] <- 0.995
                beta_valid[which(is.nan(beta_valid[,2])),2] <- 0.005
                beta_valid[which(is.nan(beta_valid[,3])),3] <- 0.995
            }
        }
        beta_sim[[m]] <- tmp2_sim
        beta_sne[[m]] <- tmp2_sne
        beta_sor[[m]] <- tmp2_sor
    }

    return(list(beta_sim = beta_sim,
                beta_sne = beta_sne,
                beta_sor = beta_sor,
                beta_valid = beta_valid))

}
