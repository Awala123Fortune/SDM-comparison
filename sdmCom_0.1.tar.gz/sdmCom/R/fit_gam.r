#' @title Fit a General(ized) Additive Model
#'
#' @param dat A list of data matrices (or data frames)
#' @param interactions_x Boolean
#' @param spatial Boolean
#' @return The model fit object(s) and computation time(s)

fit_gam <- function(dat, 
                    interactions_x, 
                    spatial,
                    save_model, 
                    save_model_true) 
    {

    gams <- list()
    gams_spat <- list()
    gams_int <- list()
    gams_int_spat <- list()
    formulas <- list()

    if (interactions_x) {
        models <- c('no_ints', 'w_ints')
    } else {
        models <- 'no_ints'
    }
    
    for (mod in models) {

        if (mod=='no_ints') {
            datx <- dat$x            
        }
        if (mod=='w_ints') {
            datx <- dat$x_1_int            
        }
    
        for (i in 1:ncol(dat$y)) {
            formulas[[i]] <- as.formula(paste(colnames(dat$y)[i], 
                                '~', 
                                paste(paste0('s(', colnames(datx), ',bs="ts")'), 
                                      collapse="+")))
        }

        gamfits	<-	vector("list", ncol(dat$y)) 
        sT <- proc.time()
        for	(i in 1:ncol(dat$y)) {	
            gamfits[[i]] <- tryCatch({ mgcv::gam(formulas[[i]],
                                                 family=binomial(link="probit"), 
                                                 data=data.frame(cbind(dat$y, datx)))},
                                error=function(e){ err <- paste("ERROR:", 
                                                                conditionMessage(e))
                                                    return(err) })
        }
        eT <- proc.time()
        cT <- eT-sT
        
        if (mod=='no_ints') {
            gams$fits <- gamfits
            gams$computation_time <- cT[[3]]
        }
        if (mod=='w_ints') {
            gams_int$fits <- gamfits
            gams_int$computation_time <- cT[[3]]    
        }

        if (spatial) {
            gamfits	<-	vector("list", ncol(dat$y)) 
            sT <- proc.time()
            for	(i in 1:ncol(dat$y)) {	
                gamfit <- NULL
                gamfit       <- tryCatch({ mgcv::gamm(formulas[[i]],
                                                      correlation=corExp(form=formula(paste('~',
                                                        paste(colnames(dat$xy), collapse='+')))), 
                                                family=binomial(link="probit"), 
                                                data=data.frame(cbind(dat$y, datx, dat$xy)))},
                                error=function(e){ err <- paste("ERROR:",conditionMessage(e))
                                                    return(err) })
                gamfits[[i]] <- gamfit
            }
            eT <- proc.time()
            cT <- eT-sT

            if (mod=='no_ints') {
                gams_spat$fits <- gamfits
                gams_spat$computation_time <- cT[[3]]
            }
            if (mod=='w_ints') {
                gams_int_spat$fits <- gamfits
                gams_int_spat$computation_time <- cT[[3]]
            }
        }
    }
    

    if (save_model_true) {
        save(gams, file = file.path(save_model, "gams.RData"))    
        save(gams_int, file = file.path(save_model, "gams_int.RData"))    
        save(gams_spat, file = file.path(save_model, "gams_spat.RData"))    
        save(gams_int_spat, file = file.path(save_model, "gams_int_spat.RData"))    
    } else {
            return(list(gams = gams, 
                        gams_int = gams_int, 
                        gams_spat = gams_spat, 
                        gams_int_spat = gams_int_spat))
    }         

}
