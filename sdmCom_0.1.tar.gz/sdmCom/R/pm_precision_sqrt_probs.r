#' @title Precision measure for marginal species occurrence probabilities
#'
#' @param occurrence_probs Occurrence probabilities (from modify_predictions)
#' @return sqrt(p(1 - p)), where p is the probability of species occurrence, averaged over species and sampling units
#'
#' @details Measure 1D from Norberg et al. (2019)

pm_precision_sqrt_probs <- function(occurrence_probs, 
                                    as_array) 

{

    if (as_array) {
        sqrt_probs <- NA
    } else {
        sqrt_probs <- vector("list", length(occurrence_probs))
        names(sqrt_probs) <- names(occurrence_probs)
    }

    for ( m in 1:length(occurrence_probs) ) {

        tmp <- vector("list", length(occurrence_probs[[m]]))
        names(tmp) <- names(occurrence_probs[[m]])
    
        for ( f in 1:length(occurrence_probs[[m]]) ) {

            tmp[[f]] <- mean(sqrt(occurrence_probs[[m]][[f]] * (1 - occurrence_probs[[m]][[f]])))
        
        }
    
        if (as_array) {
            sqrt_probs <- rbind(sqrt_probs,
                                cbind(names(occurrence_probs)[m], 
                                names(tmp), 
                                unlist(tmp))) 
        } else {
            sqrt_probs[[m]] <- tmp
        }

    }

    if (as_array) {
        sqrt_probs <- sqrt_probs[-1,]
    }

    return(precision_sqrt_probs = sqrt_probs)

}

