#' @title Fit a Generalized Linear Model
#'
#' @param dat A list of data matrices (or data frames)
#' @param poly_degree Polynomial degree (1 or 2)
#' @param interactions_x Boolean
#' @return The model fit object(s) and computation time(s)

fit_glm <- function(dat, 
                    poly_degree, 
                    interactions_x,
                    save_model,
                    save_model_true)
    {

    glms <- list()
    glms_int <- list()
    formulas <- list()

    if (interactions_x) {
        models <- c('no_ints', 'w_ints')
    } else {
        models <- 'no_ints'
    }
    
    for (mod in models) {

        if (mod=='no_ints') {
            if (poly_degree==1) {
                datx <- dat$x            
            }
            if (poly_degree==2) {
                datx <- dat$x_2           
            }
        }
        if (mod=='w_ints') {
            if (poly_degree==1) {
                datx <- dat$x_1_int            
            }
            if (poly_degree==2) {
                datx <- dat$x_poly           
            }
            datx <- dat$x_poly
        }

        for (i in 1:ncol(dat$y)) {
            formulas[[i]] <- as.formula(paste0(colnames(dat$y)[i], 
                                                '~1+', 
                                                paste(colnames(datx), collapse="+")))
        }
      
        sT <- proc.time()
            glmfits	<-	foreach	(i=1:ncol(dat$y)) %dopar% { 
                                                    tryCatch({ glm(formulas[[i]], 
                                                       family=binomial(link = "probit"), 
                                                       data=data.frame(cbind(dat$y, datx)))}, 
                            error=function(e){cat("ERROR :",conditionMessage(e), "\n")}) }
        eT <- proc.time()
        cT <- eT-sT

        if (mod=='no_ints') {
            glms$fits <- glmfits
            glms$computation_time <- cT[[3]]
        }
        if (mod=='w_ints') {
            glms_int$fits <- glmfits
            glms_int$computation_time <- cT[[3]]
        }
    }
    

    if (save_model_true) {
        save(glms, file = file.path(save_model, "glms.RData"))    
        save(glms_int, file = file.path(save_model, "glms_int.RData"))    
    } else {
        return(list(glms = glms, 
                    glms_int = glms_int))
    }

}

