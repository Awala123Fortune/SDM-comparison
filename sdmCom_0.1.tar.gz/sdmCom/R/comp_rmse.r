#' @title Compute root square mean error
#'
#' @param predictions A matrix of predicted values
#' @param validation A vector of validation values
#' @return RMSE between predicted and validation values

comp_rmse <- function(prediction, validation)

{ 

    if (length(validation) != nrow(prediction)) {
        stop("length(validation) != nrow(prediction)")
    }
    
    res <- mean(sqrt((matrix(rep(validation,
                                 times = ncol(prediction)),
                             ncol = ncol(prediction)
                            ) - prediction) ^2 ))
    return(res)
}
