#' @title Fit Species Distribution Models
#'
#' @param x Matrix
#' @param y Matrix
#' @param xy Matrix
#' @param models Models
#' @param poly_degree Polynomial degree
#' @param interactions_x Boolean
#' @param spatial Boolean
#' @param mcmcControl MCMC conditions
#' @param rfControl Tuning parameters for Random Forests
#' @param brtControl Tuning parameters for Boosted regression Trees
#' @return Fitted model objects and computation times
#'
#' @export

fit_sdmcom   <-   function(x, 
                           y, 
                           xy = NULL, 
                           models = c('glm'), 
                           interactions_x = TRUE, 
                           poly_degree = 2, 
                           save_model = NULL,
                           model_options = NULL)


    {

    confirmed_model_options <- sdmCom:::set_model_options(model_options = model_options,
                                                          models = models,
                                                          save_model = save_model)

    if (!is.null(xy)) {
        spatial <- TRUE
    } else {
        spatial <- FALSE
    }
    if ( is.null(save_model) ) {
        print("The fitted model objects will be returned as a list")
            save_model_true <- FALSE
    } else {
        if (file.exists(save_model)) {
            print(paste("The fitted model objects will be saved to", save_model))
            save_model_true <- TRUE
        } else {
            stop("Unable to define model saving options. Please provide a valid, existing directory for saving or set save_model to NULL (default)")
        }
    }
    
    modelfits <- list()

    dat <- list()
    dat$x <- apply(as.matrix(x), 2, as.numeric)
    dat$y <- apply(as.matrix(y), 2, as.numeric)
    if (spatial) {
        dat$xy <- apply(as.matrix(xy), 2, as.numeric)
    }
    colnames(dat$x) <- paste0('cov', 1:ncol(dat$x))
    colnames(dat$y) <- paste0('sp', 1:ncol(dat$y))
    if (spatial) {
    colnames(dat$xy) <- paste0('xy', 1:ncol(dat$xy))
    }
    
    dat$x_poly <- poly(as.matrix(dat$x), degree=poly_degree, raw=TRUE)
    colnames(dat$x_poly) <- paste0("cov", colnames(dat$x_poly))
    dat$x_2 <- dat$x_poly[,attributes(dat$x_poly)$degree==2]
    dat$x_2 <- cbind(dat$x_poly[,attributes(dat$x_poly)$degree==1],
                        dat$x_2[,grepl("2", c(colnames(dat$x_2)), perl=TRUE)])
    dat$x_1_int <- dat$x_poly[,attributes(dat$x_poly)$degree==2]
    dat$x_1_int <- cbind(dat$x_poly[,attributes(dat$x_poly)$degree==1],
                        dat$x_1_int[,grepl("1", c(colnames(dat$x_1_int)), perl=TRUE)])
    dat$x_poly <- as.matrix(dat$x_poly)
    class(dat$x_poly) <- "matrix"

    if('bc' %in% models) {
        modelfits$bcs <- sdmCom:::fit_bc(dat = dat, 
                                       poly_degree = poly_degree, 
                                       bcControl = confirmed_model_options$bcControl, 
                                       mcmcControl = confirmed_model_options$mcmcControl,
                                       save_model = save_model,
                                       save_model_true = save_model_true)
    }

    if('boral' %in% models) {
        modelfits$borals <- sdmCom:::fit_boral(dat = dat, 
                                             poly_degree = poly_degree, 
                                             mcmcControl = confirmed_model_options$mcmcControl,
                                             boralControl = confirmed_model_options$boralControl,
                                             save_model = save_model,
                                             save_model_true = save_model_true)
    }

    if('brt' %in% models) {
        modelfits$brts <- sdmCom:::fit_brt(dat = dat,
                                           brtControl = confirmed_model_options$brtControl,
                                           save_model = save_model,
                                           save_model_true = save_model_true)
    }

    if('glm' %in% models) {
        modelfits$glms <-    sdmCom:::fit_glm(dat = dat, 
                                     poly_degree = poly_degree, 
                                     interactions_x = interactions_x,
                                     save_model = save_model,
                                     save_model_true = save_model_true)
    }

    if('gam' %in% models) {
        modelfits$gams <- sdmCom:::fit_gam(dat = dat, 
                                          interactions_x = interactions_x, 
                                          spatial = spatial,        
                                          save_model = save_model, 
                                          save_model_true = save_model_true)
    }

    if('gjam' %in% models) {
        modelfits$gjams <- sdmCom:::fit_gjam(dat = dat, 
                                            poly_degree = poly_degree, 
                                            mcmcControl = confirmed_model_options$mcmcControl,       
                                            save_model = save_model,
                                            save_model_true = save_model_true)
    }

    if('hmsc' %in% models) {
        modelfits$hmscs <- sdmCom:::fit_hmsc(dat = dat, 
                                             poly_degree = poly_degree, 
                                             interactions_x = interactions_x, 
                                             spatial = spatial, 
                                             mcmcControl = confirmed_model_options$mcmcControl,     
                                             hmscControl = confirmed_model_options$hmscControl,        
                                             save_model = save_model,
                                             save_model_true = save_model_true)
    }

    if('rf' %in% models) {
        modelfits$rfs <- sdmCom:::fit_rf(dat = dat,
                                        rfControl = confirmed_model_options$rfControl,
                                        save_model = save_model, 
                                        save_model_true = save_model_true)
    }

    if (save_model_true) {
        save(dat, file = file.path(save_model, "train_dat.Rdata"))
        return(list(fitted_models = paste("Saved to", save_model), 
                    data = dat, 
                    model_selection = models))
    
    } else {
        return(list(fitted_models = modelfits, 
                    data = dat, 
                    model_selection = models))
    }    

}
