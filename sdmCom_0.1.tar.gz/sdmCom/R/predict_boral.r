#' @title Predict with a Bayesian Regression Model
#'
#' @param targ_model_fits Model fits
#' @param train_dat Training data
#' @param new_dat New data
#' @param nsamples Number of posterior samples
#' @param poly_degree Polynomial degree (1 or 2)
#' @return The predictions

predict_boral  <-  function(targ_model_fits,
                            train_dat,
                            new_dat, 
                            poly_degree,
                            load_model,
                            load_model_true,
                            nsamples) 
                            
                            {
            
    if (poly_degree==1) {
        newdatx <- new_dat$x            
    }
    if (poly_degree==2) {
        newdatx <- new_dat$x_2           
    }
    datymat <- as.matrix(train_dat$y)

    if (load_model_true) {
        targ_model_fits <- list()
        load(file = file.path(load_model, "boral1.RData"))    
        load(file = file.path(load_model, "boral2.RData"))    
        targ_model_fits$borals <- list(boral1 = boral1, boral2 = boral2)
    }

    preds <- vector("list", length(targ_model_fits$borals)) 
    names(preds) <- names(targ_model_fits$borals)

    for (mod in 1:length(targ_model_fits$borals)) {
        
        brl <- targ_model_fits$borals[[mod]]

		linpred_brl <- boralPredict(brl$fits, 
									newX = newdatx,
									predict.type = "marginal")
        
		brl_PAs <- linpred_brl
		
		for(k in 1:dim(linpred_brl)[3]) {
		    brl_PAs[,,k] <- matrix(rbinom(length(linpred_brl[,,k]), 
		    								1, 
		    								prob = pnorm(linpred_brl[,,k])), 
		    						 nrow = dim(linpred_brl)[1], 
		    						 ncol = dim(linpred_brl)[2])
		}

		set.seed(456)
		smplREPs <- sample(1:dim(brl_PAs)[3], nsamples, replace = TRUE)
		brl_PAs <- brl_PAs[,,smplREPs]

        dimnames(brl_PAs)[1]
        dimnames(brl_PAs)[2]
        
        preds[[mod]]$predictions <- brl_PAs
        preds[[mod]]$model_call <- brl$fits$call
    }
    
    return(list(boral1 = preds[[1]], boral2 = preds[[2]]))

}
