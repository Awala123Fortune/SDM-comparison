#' Identify your operating system
#'
#' @return Your operating system, either OSX, Unix or Windows
#' @examples
#' os <- get_os()
#' os

get_os <- function() {
  if (.Platform$OS.type == "windows") { 
    "win"
  } else if (Sys.info()["sysname"] == "Darwin") {
    "osx" 
  } else if (.Platform$OS.type == "unix") { 
    "unix"
  } else {
    stop("Unknown OS")
  }
}
