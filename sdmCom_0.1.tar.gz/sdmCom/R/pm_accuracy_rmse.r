#' @title Accuracy measure for species richness and community composition
#'
#' @param species_richness Species richness (from modify_predictions)
#' @param community_composition Community composition (from modify_predictions)
#' @return Root mean squared error (RMSE) between mean prediction and observed species richness / community composition
#'
#' @details Measures 2A and 3A from Norberg et al. (2019)

pm_accuracy_rmse <- function(species_richness = NULL,
                             community_composition = NULL,
                             as_array) 

{

    sp_rich_rmse <- NULL
    comm_comp_rmse <- NULL
    
    if (!is.null(species_richness)) {
    
        if (as_array) {
            sp_rich_rmse <- NA
        } else {
            sp_rich_rmse <- vector("list", length(species_richness$predicted))
            names(sp_rich_rmse) <- names(species_richness$predicted)
        }

        for ( m in 1:length(species_richness$predicted) ) {

            tmp <- vector("list", length(species_richness$predicted[[m]]))
            names(tmp) <- names(species_richness$predicted[[m]])
    
            for ( f in 1:length(species_richness$predicted[[m]]) ) {

                tmp[[f]] <- sdmCom:::comp_rmse(prediction = species_richness$predicted[[m]][[f]], 
                                               validation = species_richness$validation)
                                      
            }
    
            if (as_array) {
                sp_rich_rmse <- rbind(sp_rich_rmse,
                                      cbind(names(species_richness$predicted)[m], 
                                      names(tmp), 
                                      unlist(tmp))) 
            } else {
                sp_rich_rmse[[m]] <- tmp
            }
        }
        
        if (as_array) {
            sp_rich_rmse <- matrix(sp_rich_rmse[-1,], ncol = 3)
        }

    }

    if (!is.null(community_composition)) {

        if (as_array) {        
            beta_sim_rmse <- NA
            beta_sne_rmse <- NA
            beta_sor_rmse <- NA
        } else {
            beta_sim_rmse <- vector("list", length(community_composition$beta_sim))
            names(beta_sim_rmse) <- names(community_composition$beta_sim)
        
            beta_sne_rmse <- vector("list", length(community_composition$beta_sne))
            names(beta_sne_rmse) <- names(community_composition$beta_sne)
        
            beta_sor_rmse <- vector("list", length(community_composition$beta_sor))
            names(beta_sor_rmse) <- names(community_composition$beta_sor)
        }

        for ( m in 1:length(community_composition$beta_sim) ) {

            tmp_sim <- vector("list", length(community_composition$beta_sim[[m]]))
            names(tmp_sim) <- names(community_composition$beta_sim[[m]])

            tmp_sne <- vector("list", length(community_composition$beta_sne[[m]]))
            names(tmp_sne) <- names(community_composition$beta_sne[[m]])

            tmp_sor <- vector("list", length(community_composition$beta_sor[[m]]))
            names(tmp_sor) <- names(community_composition$beta_sor[[m]])

            for ( f in 1:length(community_composition$beta_sim[[m]]) ) {

                tmp_sim[[f]] <- sdmCom:::comp_rmse(prediction = community_composition$beta_sim[[m]][[f]], 
                                                   validation = community_composition$beta_valid[,1])
                                                   
                tmp_sne[[f]] <- sdmCom:::comp_rmse(prediction = community_composition$beta_sne[[m]][[f]], 
                                                   validation = community_composition$beta_valid[,2])

                tmp_sor[[f]] <- sdmCom:::comp_rmse(prediction = community_composition$beta_sor[[m]][[f]], 
                                                   validation = community_composition$beta_valid[,3])

            }

            if (as_array) {
                beta_sim_rmse <- rbind(beta_sim_rmse,
                                       cbind(names(community_composition$beta_sim)[m], 
                                       names(tmp_sim), 
                                       unlist(tmp_sim))) 
                beta_sne_rmse <- rbind(beta_sne_rmse,
                                       cbind(names(community_composition$beta_sne)[m], 
                                       names(tmp_sne), 
                                       unlist(tmp_sne))) 
                beta_sor_rmse <- rbind(beta_sor_rmse,
                                       cbind(names(community_composition$beta_sor)[m], 
                                       names(tmp_sor), 
                                       unlist(tmp_sor))) 
            } else {
                beta_sim_rmse[[m]] <- tmp_sim
                beta_sne_rmse[[m]] <- tmp_sne
                beta_sor_rmse[[m]] <- tmp_sor
            }
          
        }

        if (as_array) {            
            comm_comp_rmse <- cbind(beta_sim_rmse[-1,3],
                                    beta_sne_rmse[-1,3],
                                    beta_sor_rmse[-1,3])            
        } else {
            comm_comp_rmse <- list(beta_sim_rmse = beta_sim_rmse,
                                   beta_sne_rmse = beta_sne_rmse,
                                   beta_sor_rmse = beta_sor_rmse)
        }
    }
           
    if (as_array) {            
        res_arr <- cbind(sp_rich_rmse, comm_comp_rmse)
        colnames(res_arr) <- c("modelling framework",
                               "model variant",
                               "sp_rich_rmse", 
                               "beta_sim_rmse",
                               "beta_sne_rmse",
                               "beta_sor_rmse")
        return( res_arr )                
    } else {
        return( list(sp_richness_rmse = sp_rich_rmse,
                     community_composition_rmse = comm_comp_rmse) )        
    }
    
}
