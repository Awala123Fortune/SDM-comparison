#' @title Calculate predictive performance measures
#'
#' @param modified_predictions Object obtained with modify_predictions
#' @param pms Performance measures
#' @return Selected performance measure values
#'
#' @export

calculate_pms  <- function(modified_predictions,
                           pms = c("accuracy_expected_me",
                                   "discrimination_auc",
                                   "calibration_prob_bin_mse",
                                   "precision_sqrt_probs",
                                   "accuracy_rmse",
                                   "discrimination_spearman",
                                   "calibration_pred_interval",
                                   "precision_sd"
                                   ),
                            pred_interval = 50,
                            as_array = TRUE)

    {

    pm_acc_exp_me <- NULL
    pm_disc_auc <- NULL
    pm_calibr_prob_bin_mse <- NULL
    pm_prec_sqrt_probs <- NULL
    pm_acc_rmse <- NULL
    pm_disc_spear <- NULL
    pm_calibr_predint <- NULL
    pm_prec_sd <- NULL

    if ("accuracy_expected_me" %in% pms) {
        pm_acc_exp_me <- sdmCom:::pm_accuracy_expected_me(occurrence_probs = modified_predictions$occurrence_probabilities,
                                                          yvalid = modified_predictions$y_validation,
                                                          as_array = as_array) 
    }
    if ("discrimination_auc" %in% pms) {
        pm_disc_auc <- sdmCom:::pm_discrimination_auc(occurrence_probs = modified_predictions$occurrence_probabilities,
                                                      yvalid = modified_predictions$y_validation,
                                                      as_array = as_array) 

    }
    if ("calibration_prob_bin_mse" %in% pms) {
        pm_calibr_prob_bin_mse <- sdmCom:::pm_calibration_prob_bin_mse(occurrence_probs = modified_predictions$occurrence_probabilities,
                                                                       yvalid = modified_predictions$y_validation,
                                                                       as_array = as_array) 

    }
    if ("precision_sqrt_probs" %in% pms) {
        pm_prec_sqrt_probs <- sdmCom:::pm_precision_sqrt_probs(occurrence_probs = modified_predictions$occurrence_probabilities,
                                                               as_array = as_array) 
    }
    if ("accuracy_rmse" %in% pms) {
        pm_acc_rmse <- sdmCom:::pm_accuracy_rmse(species_richness = modified_predictions$species_richness,
                                                 community_composition = modified_predictions$community_composition,
                                                 as_array = as_array) 
    }
    if ("discrimination_spearman" %in% pms) {
        pm_disc_spear <- sdmCom:::pm_discrimination_spearm(species_richness = modified_predictions$species_richness,
                                                           community_composition = modified_predictions$community_composition,
                                                           as_array = as_array) 
    }
    if ("calibration_pred_interval" %in% pms) {
        pm_calibr_predint <- sdmCom:::pm_calibration_pred_interval(species_richness = modified_predictions$species_richness,
                                                                 community_composition = modified_predictions$community_composition,
                                                                 pred_interval = pred_interval,
                                                                 as_array = as_array) 
    }
    if ("precision_sd" %in% pms) {
        pm_prec_sd <- sdmCom:::pm_precision_sd(species_richness = modified_predictions$species_richness,
                                               community_composition = modified_predictions$community_composition,
                                               as_array = as_array) 
    }

    if (as_array) {

        res_arr <-  cbind(pm_acc_exp_me,
                          pm_disc_auc[,3],
                          pm_calibr_prob_bin_mse[,3],
                          pm_prec_sqrt_probs[,3],
                          pm_acc_rmse[,-c(1:2)],
                          pm_disc_spear[,-c(1:2)],
                          pm_calibr_predint[,-c(1:2)],
                          pm_prec_sd[,-c(1:2)] )

        colnames(res_arr)[1:6] <-  c("modelling framework", 
                                     "model variant",
                                     "accuracy_expected_me",
                                     "discrimination_auc",
                                     "calibration_prob_bin_mse",
                                     "precision_sqrt_probs")
                  
        res_arr <- data.frame(res_arr)
        res_arr[,3:ncol(res_arr)] <- apply(res_arr[,3:ncol(res_arr)], 2, as.character)
        res_arr[,3:ncol(res_arr)] <- apply(res_arr[,3:ncol(res_arr)], 2, as.numeric)
        rownames(res_arr) <- NULL
        return( res_arr )
                  
    } else {
        return( list(pm_accuracy_expected_me = pm_acc_exp_me,
                     pm_discrimination_auc = pm_disc_auc,
                     pm_calibration_prob_bin_mse = pm_calibr_prob_bin_mse,
                     pm_precision_sqrt_probs = pm_prec_sqrt_probs,
                     pm_accuracy_rmse = pm_acc_rmse,
                     pm_discrimination_spearm = pm_disc_spear,
                     pm_calibration_pred_interval = pm_calibr_predint,
                     pm_precision_sd = pm_prec_sd) )
    }

}
