#' @title Fit a Random Forest
#'
#' @param dat A list of data matrices (or data frames)
#' @param rfControl Random Forest tuning parameter settings 
#' @return The model fit object and computation time(s)

fit_rf <- function(dat, rfControl, save_model, save_model_true) {

    rfs <- list()
    rfits <- vector("list", ncol(dat$y)) 
    names(rfits) <- colnames(dat$y)
    
    sT <- proc.time()
    for (i in 1:ncol(dat$y)) {
        form <- paste0(colnames(dat$y)[i], 
                        '~.')
                        
        tuneResult <- NULL
        tuneResult <-   tryCatch({ (e1071::tune( randomForest::randomForest, 
                                                 train.x=dat$x, 
                                                 train.y=as.factor(dat$y[,i]),
                                                 importance=TRUE,
                                                 keep.forest=TRUE,
                                                 proximity=TRUE,
                                                 ranges=list(ntree=rfControl$ntrees, 
                                                             mtry=rfControl$mtrys, 
                                                             nodesize=rfControl$nodszs))) },
                                        error=function(e){ err <- paste("ERROR:",conditionMessage(e))
                                                            return(err) })


        if (inherits(tuneResult, "tune")) {	
            rfits[[paste0('sp', i)]] <- tuneResult$best.model
        } else {
            rfits[[paste0('sp', i)]] <- tuneResult
        }
    }
    eT <- proc.time()
    cT <- eT-sT

    rfs$fits <- rfits
    rfs$computation_time <- cT[[3]]

    if (save_model_true) {
        save(rfs, file = file.path(save_model, "rfs.RData"))    
    } else {
        return(list(rfs = rfs))
    }

}
