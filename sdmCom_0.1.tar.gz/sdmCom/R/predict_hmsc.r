#' @title Predict with a Hierarchical Community Model
#'
#' @param targ_model_fits Model fits
#' @param train_dat Training data
#' @param new_dat New data
#' @param nsamples Number of posterior samples
#' @param poly_degree Polynomial degree (1 or 2)
#' @return The predictions

predict_hmsc  <-   function(targ_model_fits,
                            train_dat,
                            new_dat, 
                            spatial,
                            load_model,
                            load_model_true, 
                            poly_degree,
                            nsamples) 
                            
                            {

    newdatx_orig <- new_dat$x_poly
    newdatx_df <- data.frame(newdatx_orig)
    colnames(newdatx_df) <- colnames(newdatx_orig)
    olddatx_orig <- train_dat$x_poly
    olddatx_df <- data.frame(olddatx_orig)
    colnames(olddatx_df) <- colnames(olddatx_orig)

    datymat <- as.matrix(train_dat$y)

    if (load_model_true) {
        targ_model_fits <- list()
        load(file = file.path(load_model, "hmsc1.RData"))    
        load(file = file.path(load_model, "hmsc1_int.RData"))    
        load(file = file.path(load_model, "hmsc2.RData"))    
        load(file = file.path(load_model, "hmsc2_int.RData"))    
        load(file = file.path(load_model, "hmsc3.RData"))    
        load(file = file.path(load_model, "hmsc3_int.RData"))    
        load(file = file.path(load_model, "hmsc1_ss.RData"))    
        load(file = file.path(load_model, "hmsc1_int_ss.RData"))    
        load(file = file.path(load_model, "hmsc3_ss.RData"))    
        load(file = file.path(load_model, "hmsc3_int_ss.RData"))    


        targ_model_fits$hmscs <- list(  hmsc1 = hmsc1, 
                                        hmsc1_int = hmsc1_int, 
                                        hmsc2 = hmsc2, 
                                        hmsc2_int = hmsc2_int, 
                                        hmsc3 = hmsc3, 
                                        hmsc3_int = hmsc3_int,
                                        hmsc1_ss = hmsc1_ss,
                                        hmsc1_int_ss = hmsc1_int_ss,
                                        hmsc3_ss = hmsc3_ss,
                                        hmsc3_int_ss = hmsc3_int_ss )
    }

    preds <- vector("list", length(targ_model_fits$hmscs)) 
    names(preds) <- names(targ_model_fits$hmscs)
    
    for ( mod in 1:length(targ_model_fits$hmscs) ) {

        if ( !is.null(targ_model_fits$hmscs[[mod]]$fits) ) {

            hmsc_mods <- targ_model_fits$hmscs[[mod]]

            if (!is.null(hmsc_mods$community)) {
                n_stacked_sp <- 1
            }
            if (!is.null(hmsc_mods$stacked)) {
                n_stacked_sp <- 1:length(hmsc_mods$fits)
            }

            hmsc_PAs <- array(NA, dim = list(nrow(newdatx_df)+nrow(olddatx_df), 1, nsamples))

            for (m in n_stacked_sp) {

                if (!is.null(hmsc_mods$community)) {
                    hmsc <- hmsc_mods$fits
                }
                if (!is.null(hmsc_mods$stacked)) {
                    hmsc <- hmsc_mods$fits[[m]]
                }

                newdatx <- newdatx_df[,colnames(hmsc$X)]            
                olddatx <- olddatx_df[,colnames(hmsc$X)]
                alldatx <- rbind(olddatx, newdatx)    
                alldatx <- as.matrix(alldatx)    

                rLs <- hmsc$ranLevels            
                StudyDesAll <- hmsc$studyDesign                        

                if (!is.null(hmsc$studyDesign)) {
                    studyDesNew <- matrix(NA, nrow(newdatx), 1)
                    studyDesNew[,1] <- sprintf('site_%.3d', (1+nrow(olddatx)):(nrow(newdatx)+nrow(olddatx))) 
                    studyDesNew <- as.data.frame(studyDesNew) 
                    colnames(studyDesNew) <- "Sites"
                    StudyDesAll <- rbind(hmsc$studyDesign, studyDesNew)
                    rl <- matrix(1:nrow(StudyDesAll), ncol=1)
                    rownames(rl) <- StudyDesAll[,1]
                    rLs <- list("Sites" = Hmsc::HmscRandomLevel(units=rl)) 
                }

                if (hmsc_mods$spatial) {
                    new_xy <- new_dat$xy
                    rLs_s <- hmsc$rL[[1]]
                    old_xy <- rLs_s$s
                    rownames(new_xy) <- studyDesNew[,1] 
                    colnames(new_xy) <- colnames(old_xy)
                    all_xy <- rbind(old_xy, new_xy)
                    rLs_s$pi <- StudyDesAll[,1]
                    rLs_s$s <- all_xy
                    rLs <- rLs_s
                }


# 2.4.19 
# spat prediktiot ei toimi
!all(hmsc$rLNames %in% names(ranLevels))
rL <- ranLevels[hmsc$rLNames]
? Hmsc:::HmscRandomLevel

                prs    <-  Hmsc:::predict.Hmsc(hM = hmsc, 
                                               X = alldatx,
                                               studyDesign = StudyDesAll,
                                               ranLevels = rLs,
                                               expected = FALSE)


            
                set.seed(172)
                smplREPs <- sample(1:length(prs), nsamples, replace = TRUE)
                prs <- prs[smplREPs]
                prs <- simplify2array(prs)

                if (!is.null(hmsc_mods$community)) {
                    hmsc_PAs <- prs
                }                
                if (!is.null(hmsc_mods$stacked)) {
                    hmsc_PAs <- abind(hmsc_PAs, prs, along = 2)
                }                
            }
            if (!is.null(hmsc_mods$stacked)) {
                hmsc_PAs <- hmsc_PAs[,-1,]
            }                
        } else {
            hmsc_PAs <- list() 
        }
        preds[[mod]]$predictions <- hmsc_PAs
        #preds[[mod]]$model_call <- hmsc$call
    }
    
    return(list(hmsc1 = preds[[1]], 
                hmsc1_int = preds[[2]], 
                hmsc2 = preds[[3]], 
                hmsc2_int = preds[[4]], 
                hmsc3 = preds[[5]], 
                hmsc3_int = preds[[6]],
                hmsc1_ss = preds[[7]],
                hmsc1_int_ss = preds[[8]],
                hmsc3_ss = preds[[9]],
                hmsc3_int_ss = preds[[10]]))

}
