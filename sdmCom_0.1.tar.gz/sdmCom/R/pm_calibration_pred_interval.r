#' @title Calibration measure for species richness and community composition
#'
#' @param species_richness Species richness (from modify_predictions)
#' @param community_composition Community composition (from modify_predictions)
#' @return |p-0.5|, where p is the proportion of predictions that fall within 50% prediction interval
#'
#' @details Measures 2C and 3C from Norberg et al. (2019)

pm_calibration_pred_interval <- function(species_richness = NULL,
                                         community_composition = NULL,
                                         pred_interval = 50,
                                         as_array) 

{
    pred_interval <- pred_interval / 100
    prob1 <- 0.5 - (pred_interval / 2)
    prob2 <- 0.5 + (pred_interval / 2)    
    
    sp_rich_predint <- NULL
    comm_comp_predint <- NULL
    
    if (!is.null(species_richness)) {
    
        if (as_array) {
            sp_rich_predint <- NA
        } else {
            sp_rich_predint <- vector("list", length(species_richness$predicted))
            names(sp_rich_predint) <- names(species_richness$predicted)
        }

        for ( m in 1:length(species_richness$predicted) ) {

            tmp <- vector("list", length(species_richness$predicted[[m]]))
            names(tmp) <- names(species_richness$predicted[[m]])
    
            for ( f in 1:length(species_richness$predicted[[m]]) ) {

                quant <- NULL
                quant <- apply(species_richness$predicted[[m]][[f]], 
                                  1, 
                                  quantile, 
                                  probs = c(prob1, prob2), 
                                  na.rm = TRUE, 
                                  type = 3)

                tmp[[f]] <- abs(pred_interval - (sum((species_richness$validation >= quant[1,] & species_richness$validation <= quant[2,]) * 1) / length(species_richness$validation)))

            }
    
            if (as_array) {
                sp_rich_predint <- rbind(sp_rich_predint,
                                         cbind(names(species_richness$predicted)[m], 
                                         names(tmp), 
                                         unlist(tmp)))
            } else {
                sp_rich_predint[[m]] <- tmp
            }
        }
        if (as_array) {
            sp_rich_predint <- matrix(sp_rich_predint[-1,], ncol = 3)
        }
    }

    if (!is.null(community_composition)) {

        if (as_array) {        
            beta_sim_predint <- NA
            beta_sne_predint <- NA
            beta_sor_predint <- NA
        } else {
            beta_sim_predint <- vector("list", length(community_composition$beta_sim))
            names(beta_sim_predint) <- names(community_composition$beta_sim)
        
            beta_sne_predint <- vector("list", length(community_composition$beta_sne))
            names(beta_sne_predint) <- names(community_composition$beta_sne)
        
            beta_sor_predint <- vector("list", length(community_composition$beta_sor))
            names(beta_sor_predint) <- names(community_composition$beta_sor)
        }

        for ( m in 1:length(community_composition$beta_sim) ) {

            tmp_sim <- vector("list", length(community_composition$beta_sim[[m]]))
            names(tmp_sim) <- names(community_composition$beta_sim[[m]])

            tmp_sne <- vector("list", length(community_composition$beta_sne[[m]]))
            names(tmp_sne) <- names(community_composition$beta_sne[[m]])

            tmp_sor <- vector("list", length(community_composition$beta_sor[[m]]))
            names(tmp_sor) <- names(community_composition$beta_sor[[m]])

            for ( f in 1:length(community_composition$beta_sim[[m]]) ) {

                quant <- NULL
                quant <- apply(community_composition$beta_sim[[m]][[f]], 
                                1, 
                                quantile, 
                                probs = c(prob1, prob2), 
                                na.rm = TRUE, 
                                type = 3)
                tmp_sim[[f]] <- abs(pred_interval - (sum((community_composition$beta_valid[,1] >= quant[1,] & community_composition$beta_valid[,1] <= quant[2,]) * 1) / nrow(community_composition$beta_valid)))			

                quant <- NULL
                quant <- apply(community_composition$beta_sne[[m]][[f]], 
                                1, 
                                quantile, 
                                probs = c(prob1, prob2), 
                                na.rm = TRUE, 
                                type = 3)
                tmp_sne[[f]] <- abs(pred_interval - (sum((community_composition$beta_valid[,2] >= quant[1,] & community_composition$beta_valid[,2] <= quant[2,]) * 1) / nrow(community_composition$beta_valid)))			

                quant <- NULL
                quant <- apply(community_composition$beta_sor[[m]][[f]], 
                                1, 
                                quantile, 
                                probs = c(prob1, prob2), 
                                na.rm = TRUE, 
                                type = 3)
                tmp_sor[[f]] <- abs(pred_interval - (sum((community_composition$beta_valid[,3] >= quant[1,] & community_composition$beta_valid[,3] <= quant[2,]) * 1) / nrow(community_composition$beta_valid)))			


            }

            if (as_array) {
                beta_sim_predint <- rbind(beta_sim_predint,
                                          cbind(names(community_composition$beta_sim)[m], 
                                          names(tmp_sim), 
                                          unlist(tmp_sim))) 
                beta_sne_predint <- rbind(beta_sne_predint,
                                          cbind(names(community_composition$beta_sne)[m], 
                                          names(tmp_sne), 
                                          unlist(tmp_sne))) 
                beta_sor_predint <- rbind(beta_sor_predint,
                                          cbind(names(community_composition$beta_sor)[m], 
                                          names(tmp_sor), 
                                          unlist(tmp_sor))) 
            } else {
                beta_sim_predint[[m]] <- tmp_sim
                beta_sne_predint[[m]] <- tmp_sne
                beta_sor_predint[[m]] <- tmp_sor
            }

        }

         if (as_array) {
            comm_comp_predint <- cbind(beta_sim_predint[-1,3],
                                       beta_sne_predint[-1,3],
                                       beta_sor_predint[-1,3])            
        } else {
            comm_comp_predint <- list(beta_sim_predint = beta_sim_predint,
                                      beta_sne_predint = beta_sne_predint,
                                      beta_sor_predint = beta_sor_predint)
        }
       
    }

    if (as_array) {
        res_arr <- cbind(sp_rich_predint, comm_comp_predint)
        colnames(res_arr) <- c("modelling framework",
                               "model variant",
                               "sp_rich_predint", 
                               "beta_sim_predint",
                               "beta_sne_predint",
                               "beta_sor_predint")
        return( res_arr )                
    } else {
        return(list(sp_richness_predint = sp_rich_predint,
                    community_composition_predint = comm_comp_predint))
    }

}
