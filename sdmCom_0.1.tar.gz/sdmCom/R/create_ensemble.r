#' @title Create an ensemble of predictions from multiple model variants
#'
#' @param ensemble A list defining the ensemble (see Details and Examples)
#' @param predictions A predict_sdmcom object
#' @param nsamples Total number of samples wanted
#' @return Selected performance measure values
#'

create_ensemble <- function(ensemble,
                            predictions,
                            nsamples) {

    if (!is.list(ensemble)) {
        if (ensemble == 'all') {
            ensemble <- vector('list', length(predictions$predictions))
            names(ensemble) <- names(predictions$predictions)
            for (i in 1:length(predictions$predictions)) {
                ensemble[[i]] <- 'all'
            }
            ens_all_names <- list()
            for (m in 1:length(ensemble)) {
                ens_all_names[[m]] <- names(predictions$predictions[[m]])
            }
        } else {
            stop("Ensemble not stated cleraly, should be 'all' or a list")
        }
    } else {    
        ens_all_names <- list()
        for (m in 1:length(ensemble)) {
            if (ensemble[[m]][1]=='all') {
                ens_all_names[[m]] <- names(predictions$predictions[[m]])
            } else {
                ens_all_names[[m]] <- ensemble[[m]]
            }
        }
    }
    ens_all_names <- unlist(ens_all_names)

    div <- ceiling(nsamples / length(ens_all_names))

    ens_preds <- array(NA, dim = c(dim(predictions$predictions[[1]][[1]][[1]])[1:2], 1))
    for (m in 1:length(ensemble)) {

        if (ensemble[[m]][1]=='all') {
    
            for (f in 1:length(predictions$predictions[[names(ensemble)[m]]])) {

                ens_preds <- abind:::abind(ens_preds, 
                                           predictions$predictions[[names(ensemble)[m]]][[f]]$predictions[,,sample(1:dim(predictions$predictions[[names(ensemble)[m]]][[f]]$predictions)[3],
                                                                                                            div, 
                                                                                                            replace = TRUE)])

            }
        } else {

            for (f in 1:length(ensemble[[m]])) {

                ens_preds <- abind:::abind(ens_preds, 
                                           predictions$predictions[[names(ensemble)[m]]][[ensemble[[m]][f]]]$predictions[,,sample(1:dim(predictions$predictions[[names(ensemble)[m]]][[ensemble[[m]][f]]]$predictions)[3],
                                                                                                                                  div, 
                                                                                                                                  replace = TRUE)])

            }
        
        }

    }
    ens_preds <- ens_preds[,,-1]

    if (dim(ens_preds)[3] > nsamples) {
    ens_preds <- ens_preds[,,sample(1:dim(ens_preds)[3],
                                    nsamples, 
                                    replace = FALSE)]
    }

    return(ens_preds)

}
