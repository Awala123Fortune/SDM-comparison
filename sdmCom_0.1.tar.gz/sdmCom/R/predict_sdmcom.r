#' @title Predict with fitted Species Distribution Models
#'
#' @param model_fits Fitted models, resulting from fit_models
#' @param new_x Matrix
#' @param new_xy Matrix
#' @param models Models of interest
#' @param poly_degree Polynomial degree
#' @param interactions_x Boolean
#' @param spatial Boolean
#' @param load_model Path to the directory where all the fitted model objects are saved
#' @return Fitted model objects and computation times
#'
#' @export

predict_sdmcom   <-   function(model_fits = NULL,
                               new_x, 
                               new_xy = NULL, 
                               models = NULL, 
                               interactions_x = TRUE, 
                               poly_degree = 2, 
                               nsamples = 100,
                               load_model = NULL)

{
    
    if (!is.null(new_xy)) {
        spatial <- TRUE
    } else {
        spatial <- FALSE
    }
    load_model_true <- FALSE
    if ( !is.null(load_model) ) {
        if ( file.exists(load_model) ) {
            print(paste("Loading model objects and training data from", load_model))
            load_model_true <- TRUE
            load(file.path(load_model, "train_dat.Rdata"))
            dat_old <- dat
            dat <- NULL
        } else {
            if ( is.null(model_fits) ) {
                stop("Provide model fits or a directory where they are located")
            } else {
                dat_old <- model_fits$data
                print("No directiry for model objects defined, expecting (and using) given model_fits")
            }
        }
    } else {
            if ( is.null(model_fits) ) {
                stop("Provide model fits or a directory where they are located")
            } else {
                dat_old <- model_fits$data
                print("No directiry for model objects defined, expecting (and using) given model_fits")  
            }      
    }
    
    predictions <- list()

    dat <- list()
    if ( !is.null(new_xy) ) {
        dat$xy <- apply(as.matrix(new_xy), 2, as.numeric)
    }
    dat$x <- apply(as.matrix(new_x), 2, as.numeric)
    if (!is.null(new_xy)) {
        dat$xy <- apply(as.matrix(new_xy), 2, as.numeric)
        colnames(dat$xy) <- paste0('xy', 1:ncol(dat$xy))
    }
    colnames(dat$x) <- paste0('cov', 1:ncol(dat$x))

    dat$x_poly <- poly(as.matrix(dat$x), degree=poly_degree, raw=TRUE)
    colnames(dat$x_poly) <- paste0("cov", 
                                   colnames(dat$x_poly))
    dat$x_2 <- dat$x_poly[,attributes(dat$x_poly)$degree==2]
    dat$x_2 <- cbind(dat$x_poly[,attributes(dat$x_poly)$degree==1],
                     dat$x_2[,grepl("2", c(colnames(dat$x_2)), perl = TRUE)])
    dat$x_1_int <- dat$x_poly[,attributes(dat$x_poly)$degree==2]
    dat$x_1_int <- cbind(dat$x_poly[,attributes(dat$x_poly)$degree==1],
                         dat$x_1_int[,grepl("1", c(colnames(dat$x_1_int)), perl=TRUE)])
    dat$x_poly <- as.matrix(dat$x_poly)

    if('glm' %in% models) {
        predictions$glms <- sdmCom:::predict_glm(targ_model_fits = model_fits$fitted_models,
                                                 train_dat = dat_old,
                                                 new_dat = dat, 
                                                 nsamples = nsamples,
                                                 poly_degree = poly_degree,
                                                 interactions_x = interactions_x,
                                                 load_model = load_model,
                                                 load_model_true = load_model_true)        
    }
    if('bc' %in% models) {
        predictions$bcs <- sdmCom:::predict_bc(targ_model_fits = model_fits$fitted_models,
                                                train_dat = dat_old,
                                                new_dat = dat, 
                                                nsamples = nsamples,
                                                poly_degree = poly_degree,
                                                load_model = load_model,
                                                load_model_true = load_model_true)        
    }
    if('boral' %in% models) {
        predictions$borals <- sdmCom:::predict_boral(targ_model_fits = model_fits$fitted_models,
                                                     train_dat = dat_old,
                                                     new_dat = dat, 
                                                     nsamples = nsamples,
                                                     poly_degree = poly_degree,
                                                     load_model = load_model,
                                                     load_model_true = load_model_true)        
    }
    if('gjam' %in% models) {
        predictions$gjams  <-  sdmCom:::predict_gjam(targ_model_fits = model_fits$fitted_models,
                                                    train_dat = dat_old,
                                                    new_dat = dat,
                                                    nsamples = nsamples,
                                                    poly_degree = poly_degree,
                                                    load_model = load_model,
                                                    load_model_true = load_model_true)        
    }
  if('hmsc' %in% models) {
      predictions$hmscs  <-  sdmCom:::predict_hmsc( targ_model_fits = model_fits$fitted_models,
                                                    train_dat = dat_old,
                                                    new_dat = dat,
                                                    spatial = spatial,
                                                    nsamples = nsamples,
                                                    poly_degree = poly_degree,
                                                    load_model = load_model,
                                                    load_model_true = load_model_true)        
  }

    return( list(predictions = predictions, 
                 new_data = dat, 
                 model_selection = models) )
    
}
