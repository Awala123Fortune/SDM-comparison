#' @title Predict wit a Generalized Joint Attribute Model
#'
#' @param targ_model_fits Model fits
#' @param train_dat Training data
#' @param new_dat New data
#' @param nsamples Number of posterior samples
#' @param poly_degree Polynomial degree (1 or 2)
#' @return The predictions

predict_gjam  <-    function(targ_model_fits,
                             train_dat,
                             new_dat, 
                             nsamples,
                             load_model,
                             load_model_true, 
                             poly_degree)
                             
    {
            
    if (poly_degree==1) {
        newdatx <- new_dat$x            
    }
    if (poly_degree==2) {
        newdatx <- new_dat$x_2           
    }

	colnames(newdatx) <- letters[1:ncol(newdatx)]
	newdatx <- list(xdata = as.data.frame(newdatx), nsim = nsamples)
    datymat <- as.matrix(train_dat$y)

    if (load_model_true) {
        targ_model_fits <- list()
        load(file = file.path(load_model, "gjam1.RData"))    
        targ_model_fits$gjams <- list(gjam1 = gjam1)
    }

    preds <- vector("list", length(targ_model_fits$gjams)) 
    names(preds) <- names(targ_model_fits$gjams)
        
    gjm <- targ_model_fits$gjams[[1]]

	gjm_pred    <-    gjam::gjamPredict(gjm$fits, 
							            newdata = newdatx, 
							            FULL = TRUE)	
		
	gjm_pred_w0sp <- array(NA,
						  dim = list(nrow(newdatx$xdata),
						  		     ncol(datymat),
						  		     nsamples),
						  dimnames = list(1:nrow(newdatx$xdata),
										  colnames(datymat),
										  1:nsamples))			

	for (i in 1:nsamples) {
		gjm_pred_w0sp[,,i] <- rbinom(rep(colMeans(datymat),
										  each = nrow(newdatx$xdata)),
									  1,
									  rep(colMeans(datymat),
										  each = nrow(newdatx$xdata)))
										  
		tmp <- matrix(gjm_pred$ychains[i,],
					  nrow(newdatx$xdata),
					  length(gjm$no0sp))
					dim(tmp)
					dim(gjm_pred_w0sp)
					dim(gjm_pred_w0sp[,gjm$no0sp,i])
		gjm_pred_w0sp[,gjm$no0sp,i] <- rbinom(tmp, 1, tmp)
	}
	gjm1_PAs <- gjm_pred_w0sp

    preds[[1]]$predictions <- gjm1_PAs
    preds[[1]]$no0sp <- gjm$no0sp
    preds[[1]]$modelList <- gjm$fits$modelList$REDUCT

    return(list(gjam1 = preds[[1]]))

}
