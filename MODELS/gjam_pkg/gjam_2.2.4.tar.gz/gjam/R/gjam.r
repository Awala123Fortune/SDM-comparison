
gjam <- function(formula, xdata, ydata, modelList){
  
  .gjam(formula, xdata, ydata, modelList)
}

  
