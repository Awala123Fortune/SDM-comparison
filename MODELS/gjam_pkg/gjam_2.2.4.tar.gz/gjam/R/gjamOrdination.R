

gjamOrdination <- function(output, specLabs = NULL, col = NULL, cex = 1, 
                           PLOT=T, method = 'PCA'){
  
  invisible( .gjamOrd( output, specLabs, col, cex, PLOT, method ) )
}
